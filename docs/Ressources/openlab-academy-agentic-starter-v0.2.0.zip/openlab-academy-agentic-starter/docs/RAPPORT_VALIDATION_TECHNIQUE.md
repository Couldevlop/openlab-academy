# Rapport de validation technique — socle 0.2.0

## Environnement de vérification
- Python : 3.13.5
- Pydantic : 2.13.5
- pytest : 9.0.2
- Système de test : environnement local du générateur de pack

## Résultats
- `pytest -q` : **16 tests réussis**.
- `python -m compileall -q src tests` : réussite.
- `python -m agentic_lab` : exécution réussie ; 5 factures éligibles, exposition de 7 730,00 EUR, aucun envoi.
- Scénario à 60 jours : 2 factures, 4 990,00 EUR.
- Validation/reprise : test d'interruption après demande d'approbation, réouverture de l'état JSON, approbation et enregistrement simulé sans doublon.

## Limites de cette validation
- Python 3.11 et 3.12 n'ont pas été exécutés dans cet environnement ; ils restent les versions recommandées pour la cohorte si elles sont disponibles sur les postes.
- Ruff n'était pas installé dans l'environnement de validation ; le lint n'est donc pas déclaré réussi.
- Aucun fournisseur LLM, Ollama, serveur MCP ou A2A n'est branché dans cette version.
- L'état JSON local et l'approbation simulée sont pédagogiques ; ce n'est pas un mécanisme de production ou une authentification réelle.

## Commandes de reproduction
```bash
python -m pip install -e ".[dev]"
pytest -q
python -m agentic_lab
```

Le premier lancement avec état vierge crée `.local/state.json`. Supprimer ce fichier pour repartir d'un état pédagogique propre.
