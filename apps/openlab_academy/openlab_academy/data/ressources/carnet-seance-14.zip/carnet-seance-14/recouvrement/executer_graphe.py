"""Lance le graphe, s'arrete pour la validation humaine, puis reprend le meme fil."""
import pathlib
import sys

from langchain_core.messages import HumanMessage, SystemMessage

from recouvrement.config import Reglages
from recouvrement.graphe import construire
from recouvrement.trace import Trace

SYSTEME = pathlib.Path("prompts/agent.md").read_text(encoding="utf-8")


def main(fil: str) -> int:
    reglages = Reglages.depuis_environnement()
    trace = Trace(pathlib.Path(f".local/trace-{fil}.jsonl"))
    graphe = construire(reglages, trace)
    config = {"configurable": {"thread_id": fil}, "recursion_limit": 25}

    etat_initial = {
        "messages": [SystemMessage(content=SYSTEME),
                     HumanMessage(content="Prepare les relances des impayes de plus de 30 jours.")],
        "brouillons": [], "jetons": 0, "statut": "en_cours",
    }
    resultat = graphe.invoke(etat_initial, config)

    instantane = graphe.get_state(config)
    if instantane.next:                       # le graphe est en pause avant "valider"
        print(f"{len(resultat['brouillons'])} brouillon(s) prepare(s) :")
        for identifiant in resultat["brouillons"]:
            print("  -", identifiant)
        reponse = input("Approuver l'enregistrement simule ? [o/N] ").strip().lower()
        if reponse != "o":
            print("Refus enregistre, rien n'a ete ecrit.")
            return 0
        resultat = graphe.invoke(None, config)   # None : on reprend, on ne recommence pas

    print("Statut final :", resultat.get("statut"), "| jetons :", resultat.get("jetons"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "demo"))
