"""Assemblage et compilation du graphe. Le seul fichier qui connait LangGraph."""
import pathlib
import sqlite3

from langchain_openai import ChatOpenAI
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from recouvrement.config import Reglages
from recouvrement.graphe_etat import EtatRecouvrement
from recouvrement.graphe_noeuds import faire_agir, faire_decider, prochaine_etape, valider
from recouvrement.outils import REGISTRE
from recouvrement.outils_schema import pour_le_modele
from recouvrement.trace import Trace

BASE = pathlib.Path(".local/graphe.sqlite")


def construire(reglages: Reglages, trace: Trace):
    modele = ChatOpenAI(model=reglages.modele, temperature=0,
                        max_tokens=reglages.jetons_max,
                        api_key=reglages.cle, base_url=reglages.adresse)
    modele_lie = modele.bind_tools(pour_le_modele(REGISTRE))

    graphe = StateGraph(EtatRecouvrement)
    graphe.add_node("decider", faire_decider(modele_lie, trace))
    graphe.add_node("agir", faire_agir(trace))
    graphe.add_node("valider", valider)

    graphe.add_edge(START, "decider")
    graphe.add_conditional_edges("decider", prochaine_etape,
                                 {"agir": "agir", "valider": "valider", "fin": END})
    graphe.add_edge("agir", "decider")      # l'observation repart vers la decision
    graphe.add_edge("valider", END)         # la reprise se fait par une invocation

    BASE.parent.mkdir(parents=True, exist_ok=True)
    connexion = sqlite3.connect(BASE, check_same_thread=False)
    return graphe.compile(checkpointer=SqliteSaver(connexion),
                          interrupt_before=["valider"])
