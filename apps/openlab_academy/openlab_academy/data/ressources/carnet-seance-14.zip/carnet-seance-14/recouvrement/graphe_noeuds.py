"""Les noeuds du graphe : des fonctions ordinaires, testables sans le cadre."""
import json
from typing import Any

from langchain_core.messages import AIMessage, ToolMessage

from recouvrement.graphe_etat import EtatRecouvrement
from recouvrement.outils import REGISTRE, executer_outil
from recouvrement.trace import Trace

ECRITURES = {"enregistrer_relance_simulee"}      # exigent un accord humain


def faire_decider(modele_lie, trace: Trace):
    """modele_lie : le modele deja muni des outils (voir l'etape suivante)."""

    def decider(etat: EtatRecouvrement) -> dict[str, Any]:
        reponse = modele_lie.invoke(etat["messages"])
        usage = getattr(reponse, "usage_metadata", None) or {}
        consommes = usage.get("total_tokens", 0)
        trace.ecrire(evenement="decision", jetons=consommes,
                     outils=[a["name"] for a in getattr(reponse, "tool_calls", [])])
        return {"messages": [reponse], "jetons": etat["jetons"] + consommes}

    return decider


def faire_agir(trace: Trace):
    def agir(etat: EtatRecouvrement) -> dict[str, Any]:
        dernier: AIMessage = etat["messages"][-1]
        sorties, brouillons = [], list(etat["brouillons"])
        for appel in dernier.tool_calls:
            # votre point d'appel : liste blanche, contrats, journal des refus
            resultat = executer_outil(appel["name"], appel["args"])
            trace.ecrire(evenement="appel_outil", outil=appel["name"],
                         arguments=appel["args"], ok=resultat.get("ok"))
            if resultat.get("ok") and resultat.get("brouillon_id"):
                brouillons.append(resultat["brouillon_id"])
            sorties.append(ToolMessage(
                content=json.dumps(resultat, ensure_ascii=False),
                tool_call_id=appel["id"]))
        return {"messages": sorties, "brouillons": brouillons}

    return agir


def valider(etat: EtatRecouvrement) -> dict[str, Any]:
    """Marque l'attente : le graphe s'arrete ici jusqu'a une reprise explicite."""
    return {"statut": "attente_validation"}


def prochaine_etape(etat: EtatRecouvrement) -> str:
    """L'arete conditionnelle : c'est vous qui decidez de la suite, pas le cadre."""
    if etat["jetons"] >= 60_000:
        return "fin"
    dernier = etat["messages"][-1]
    appels = getattr(dernier, "tool_calls", [])
    if not appels:
        return "fin"
    if any(appel["name"] in ECRITURES for appel in appels):
        return "valider"
    return "agir"
