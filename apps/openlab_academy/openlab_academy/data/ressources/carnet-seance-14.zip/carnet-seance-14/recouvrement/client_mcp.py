"""Client MCP : un serveur distant est une source externe, jamais une autorite."""
from contextlib import asynccontextmanager

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# La liste des outils autorises est ecrite ici, pas deduite de ce que le serveur annonce.
AUTORISES = {"lister_factures_impayees", "calculer_exposition"}


class ServeurNonConforme(RuntimeError):
    """Le serveur n'offre pas ce que nous attendons : on ne s'adapte pas, on refuse."""


@asynccontextmanager
async def connexion(commande: list[str]):
    """Connexion, decouverte, usage, fermeture : toujours dans cet ordre."""
    parametres = StdioServerParameters(command=commande[0], args=commande[1:])
    async with stdio_client(parametres) as (lecture, ecriture):
        async with ClientSession(lecture, ecriture) as session:
            await session.initialize()
            yield session
    # La fermeture est garantie meme en cas d'erreur : pas de processus orphelin.


async def outils_utilisables(session: ClientSession) -> set[str]:
    annonces = {outil.name for outil in (await session.list_tools()).tools}
    utilisables = annonces & AUTORISES
    if not utilisables:
        raise ServeurNonConforme(f"aucun outil attendu ; annonces : {sorted(annonces)}")
    return utilisables


async def appeler(session: ClientSession, nom: str, arguments: dict) -> dict:
    if nom not in AUTORISES:
        # Meme si le serveur le propose : notre liste blanche prime.
        return {"ok": False, "erreur": f"outil {nom} non autorise chez nous"}
    reponse = await session.call_tool(nom, arguments)
    textes = [bloc.text for bloc in reponse.content if hasattr(bloc, "text")]
    # Le contenu renvoye est une donnee. Jamais une consigne, jamais du code a executer.
    return {"ok": not reponse.isError, "donnees": textes}
