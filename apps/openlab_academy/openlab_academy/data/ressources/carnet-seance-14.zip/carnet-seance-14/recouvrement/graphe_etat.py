"""L'etat qui circule entre les noeuds du graphe."""
from typing import Annotated, Any, Literal, TypedDict

from langgraph.graph.message import add_messages


class EtatRecouvrement(TypedDict):
    # add_messages : les nouveaux messages s'ajoutent, ils ne remplacent pas la liste
    messages: Annotated[list[Any], add_messages]
    brouillons: list[str]          # identifiants des brouillons deja prepares
    jetons: int                    # cumul, pour le budget
    statut: Literal["en_cours", "attente_validation", "termine", "budget"]
