"""Un specialiste : il execute une mission bornee et rend un rapport honnete."""
from multi.contrats_echange import OrdreDeMission, Rapport
from recouvrement.outils import executer_outil
from recouvrement.trace import Trace


async def traiter_mission(ordre: OrdreDeMission, trace: Trace) -> Rapport:
    brouillons: list[str] = []
    non_traitees: list[str] = []
    depense = 0

    for tour, facture_id in enumerate(ordre.factures):
        # Les limites recues sont respectees, pas renegociees.
        if tour >= ordre.tours_maximum or depense >= ordre.budget_fcfa:
            non_traitees.extend(ordre.factures[tour:])
            break
        resultat = executer_outil("preparer_brouillon_relance",
                                  {"facture_id": facture_id, "palier": 1},
                                  trace=trace)
        depense += 20                          # cout simule d'un tour de modele
        if resultat["ok"]:
            brouillons.append(resultat["donnees"]["brouillon_id"])
        else:
            # L'echec partiel est nomme : le superviseur saura quoi reprendre.
            non_traitees.append(facture_id)

    if not brouillons:
        return Rapport(mission_id=ordre.mission_id, reussi=False,
                       motif_echec="aucun brouillon preparable sur ce lot",
                       factures_non_traitees=non_traitees,
                       tours_consommes=len(ordre.factures), depense_fcfa=depense)
    return Rapport(mission_id=ordre.mission_id, reussi=True, brouillons=brouillons,
                   factures_non_traitees=non_traitees,
                   tours_consommes=len(brouillons), depense_fcfa=depense)
