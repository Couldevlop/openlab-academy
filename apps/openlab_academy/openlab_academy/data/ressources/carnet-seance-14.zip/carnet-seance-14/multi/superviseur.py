"""Decouper, distribuer, verifier, agreger. Le reste est du detail."""
import asyncio
import uuid

from multi.contrats_echange import OrdreDeMission, Rapport
from multi.specialiste import traiter_mission
from recouvrement.outils import executer_outil
from recouvrement.trace import Trace

TAILLE_LOT = 4
BUDGET_TOTAL_FCFA = 500


def _decouper(factures: list[str]) -> list[list[str]]:
    """Des lots disjoints : c'est ce qui autorise le parallele sans verrou."""
    return [factures[i:i + TAILLE_LOT] for i in range(0, len(factures), TAILLE_LOT)]


async def orchestrer(age_min_jours: int = 30, trace: Trace | None = None) -> dict:
    trace = trace or Trace()
    liste = executer_outil("lister_factures_impayees",
                           {"age_min_jours": age_min_jours}, trace=trace)
    if not liste["ok"]:
        return {"reussi": False, "motif": liste["erreur"]}
    factures = [f["facture_id"] for f in liste["donnees"]["factures"]]
    lots = _decouper(factures)

    # Le budget se divise avant de partir : il ne se negocie pas en route.
    budget_par_lot = max(10, BUDGET_TOTAL_FCFA // max(1, len(lots)))
    ordres = [OrdreDeMission(mission_id=f"MIS-{uuid.uuid4().hex[:3].upper()}",
                             objectif="preparer un brouillon de palier 1 par facture",
                             factures=lot, budget_fcfa=budget_par_lot)
              for lot in lots]

    rapports = await asyncio.gather(*[traiter_mission(o, trace) for o in ordres],
                                    return_exceptions=True)
    return _agreger(ordres, rapports, trace)


def _agreger(ordres: list[OrdreDeMission], rapports: list, trace: Trace) -> dict:
    brouillons: list[str] = []
    non_traitees: list[str] = []
    depense = 0
    total_fcfa = 0
    for ordre, rapport in zip(ordres, rapports):
        # Panne 1 : un specialiste qui leve une exception ne doit pas tout arreter.
        if isinstance(rapport, BaseException):
            trace.ecrire(evenement="specialiste_en_erreur", mission=ordre.mission_id,
                         type=type(rapport).__name__)
            non_traitees.extend(ordre.factures)
            continue
        # Panne 2 : un rapport incoherent est refuse, pas agrege en silence.
        if not isinstance(rapport, Rapport) or not rapport.est_coherent():
            trace.ecrire(evenement="rapport_incoherent", mission=ordre.mission_id)
            non_traitees.extend(ordre.factures)
            continue
        depense += rapport.depense_fcfa
        if rapport.reussi:
            brouillons.extend(rapport.brouillons)
            # Chaque specialiste a deja fait calculer son total par l'outil : le
            # superviseur additionne, il ne recalcule pas sur des identifiants de
            # brouillons, qui ne sont pas des identifiants de factures.
            total_fcfa += rapport.total_fcfa
        # Panne 3 : les factures ecartees remontent nommement, jamais en resume.
        non_traitees.extend(rapport.factures_non_traitees)

    return {"reussi": bool(brouillons), "brouillons": brouillons,
            "factures_non_traitees": sorted(set(non_traitees)),
            "total_fcfa": total_fcfa,
            "depense_fcfa": depense, "lots": len(ordres)}
