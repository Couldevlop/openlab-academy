"""Ce qui circule entre agents, fige avant d'ecrire le moindre agent."""
from pydantic import BaseModel, Field


class OrdreDeMission(BaseModel):
    """Un contrat, pas une conversation : le superviseur demande, il ne discute pas."""
    mission_id: str = Field(pattern=r"^MIS-[A-Z0-9]{3}$")
    objectif: str = Field(min_length=10, max_length=400)
    factures: list[str] = Field(min_length=1, max_length=10)
    # Les limites sont distribuees par le superviseur, jamais choisies par l'execute.
    tours_maximum: int = Field(default=4, ge=1, le=8)
    budget_fcfa: int = Field(default=120, ge=10, le=1000)


class Rapport(BaseModel):
    """Le retour d'un specialiste. L'echec y est une reponse valide."""
    mission_id: str
    reussi: bool
    # Rempli quand reussi vaut vrai.
    brouillons: list[str] = Field(default_factory=list)
    total_fcfa: int = 0
    # Rempli quand reussi vaut faux : sans ce champ, l'echec devient silencieux.
    motif_echec: str = ""
    factures_non_traitees: list[str] = Field(default_factory=list)
    # Toujours rempli : c'est ce qui permet de mesurer le surcout du decoupage.
    tours_consommes: int = 0
    depense_fcfa: int = 0

    def est_coherent(self) -> bool:
        """Un rapport reussi sans brouillon, ou echoue sans motif, est invalide."""
        if self.reussi:
            return bool(self.brouillons) and not self.motif_echec
        return bool(self.motif_echec)
