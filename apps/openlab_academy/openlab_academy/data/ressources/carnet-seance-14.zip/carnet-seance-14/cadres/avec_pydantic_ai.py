"""Le fil rouge avec PydanticAI : la sortie est typee, donc verifiable.
Installation : pip install "pydantic-ai-slim[openai]==0.4.*" (epinglez la version)."""
from dataclasses import dataclass

from pydantic import BaseModel, Field
from pydantic_ai import Agent, ModelRetry, RunContext

from recouvrement.outils import executer_outil
from recouvrement.trace import Trace


@dataclass
class Dependances:
    trace: Trace


class Rapport(BaseModel):
    """La forme exacte attendue : plus rien a interpreter en aval."""
    factures_retenues: list[str] = Field(min_length=0, max_length=20)
    total_fcfa: int = Field(ge=0)
    brouillons: list[str]
    exclusions: dict[str, str] = Field(default_factory=dict)   # facture -> motif


agent = Agent(
    "openai:gpt-4o-mini",
    deps_type=Dependances,
    output_type=Rapport,
    system_prompt=(
        "Tu prepares des brouillons de relance. Utilise les outils pour lire les "
        "donnees et preparer les brouillons. N'invente aucun montant. "
        "Une facture en litige n'est jamais relancee ; indique-la dans exclusions."),
)


@agent.tool
def lister_factures_impayees(contexte: RunContext[Dependances],
                             age_min_jours: int, exclure_litiges: bool = True) -> dict:
    """Liste les factures dont le retard atteint age_min_jours, litiges exclus."""
    resultat = executer_outil("lister_factures_impayees",
                              {"age_min_jours": age_min_jours,
                               "exclure_litiges": exclure_litiges})
    contexte.deps.trace.ecrire(evenement="appel_outil", outil="lister_factures_impayees",
                               ok=resultat.get("ok"))
    return resultat


@agent.tool
def preparer_brouillon_relance(contexte: RunContext[Dependances],
                               facture_id: str, palier: int = 1) -> dict:
    """Prepare un brouillon local de relance. Aucun envoi, aucune ecriture definitive."""
    resultat = executer_outil("preparer_brouillon_relance",
                              {"facture_id": facture_id, "palier": palier})
    contexte.deps.trace.ecrire(evenement="appel_outil",
                               outil="preparer_brouillon_relance", ok=resultat.get("ok"))
    return resultat


@agent.output_validator
def verifier_le_rapport(contexte: RunContext[Dependances], rapport: Rapport) -> Rapport:
    """Une regle metier violee fait rejouer le modele, sans boucle ecrite a la main."""
    if len(rapport.brouillons) != len(rapport.factures_retenues):
        raise ModelRetry("un brouillon par facture retenue, ni plus ni moins")
    if rapport.total_fcfa <= 0 and rapport.factures_retenues:
        raise ModelRetry("le total ne peut pas etre nul si des factures sont retenues")
    return rapport


def executer(trace: Trace) -> Rapport:
    resultat = agent.run_sync(
        "Prepare les relances des impayes de plus de 30 jours.",
        deps=Dependances(trace=trace))
    return resultat.output
