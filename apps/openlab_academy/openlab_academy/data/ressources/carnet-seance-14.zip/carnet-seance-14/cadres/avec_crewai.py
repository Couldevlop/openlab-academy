"""Le fil rouge avec CrewAI : des roles, des taches, un processus sequentiel.
Installation : pip install "crewai==0.80.*" (epinglez, l'API bouge vite)."""
import json
from typing import Any, Type

from crewai import Agent, Crew, Process, Task
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from recouvrement.outils import executer_outil      # votre point d'appel, inchange
from recouvrement.trace import Trace


class ArgumentsLister(BaseModel):
    age_min_jours: int = Field(ge=0, le=365)
    exclure_litiges: bool = True


class OutilLister(BaseTool):
    name: str = "lister_factures_impayees"
    description: str = ("Liste les factures dont le retard atteint age_min_jours. "
                        "Exclut les litiges. Ne renvoie jamais les notes libres.")
    args_schema: Type[BaseModel] = ArgumentsLister

    def _run(self, **arguments: Any) -> str:
        # l'enveloppe ne fait que deleguer : la liste blanche reste votre affaire
        return json.dumps(executer_outil(self.name, arguments), ensure_ascii=False)


class ArgumentsBrouillon(BaseModel):
    facture_id: str = Field(pattern=r"^FAC-\d{3}$")
    palier: int = Field(ge=1, le=3)


class OutilBrouillon(BaseTool):
    name: str = "preparer_brouillon_relance"
    description: str = ("Prepare un brouillon local de relance pour une facture eligible. "
                        "Aucun envoi. Refuse les factures en litige.")
    args_schema: Type[BaseModel] = ArgumentsBrouillon

    def _run(self, **arguments: Any) -> str:
        return json.dumps(executer_outil(self.name, arguments), ensure_ascii=False)


def construire_equipe(modele: str) -> Crew:
    analyste = Agent(
        role="Analyste du poste client",
        goal="Identifier les factures relancables et chiffrer l'exposition",
        backstory="Tu travailles sur des donnees fictives et tu n'envoies jamais rien.",
        tools=[OutilLister()], llm=modele, verbose=False, allow_delegation=False)
    redacteur = Agent(
        role="Redacteur de relances",
        goal="Preparer un brouillon par facture relancable, sans jamais en envoyer",
        backstory="Tu ecris sobrement et tu n'utilises aucune note libre des factures.",
        tools=[OutilBrouillon()], llm=modele, verbose=False, allow_delegation=False)

    analyse = Task(
        description="Liste les factures de plus de 30 jours hors litige, puis donne "
                    "leurs identifiants et le total en francs CFA.",
        expected_output="Une liste d'identifiants et un total en francs CFA.",
        agent=analyste)
    redaction = Task(
        description="Prepare un brouillon de palier 1 pour chaque facture listee.",
        expected_output="Un identifiant de brouillon par facture.",
        agent=redacteur, context=[analyse])

    return Crew(agents=[analyste, redacteur], tasks=[analyse, redaction],
                process=Process.sequential, verbose=False)


def executer(modele: str, trace: Trace) -> dict:
    equipe = construire_equipe(modele)
    resultat = equipe.kickoff(inputs={"seuil": 30})
    trace.ecrire(evenement="crewai_termine", sortie=str(resultat)[:400])
    # la validation humaine et l'enregistrement restent hors du cadre, dans votre code
    return {"brouillons": [], "sortie": str(resultat)}
