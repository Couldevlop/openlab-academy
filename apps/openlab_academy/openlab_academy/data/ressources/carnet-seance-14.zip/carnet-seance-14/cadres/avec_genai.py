"""Le fil rouge avec le SDK GenAI de Google : les fonctions Python sont les outils.
Installation : pip install "google-genai==1.*" (epinglez la version)."""
import os

from google import genai
from google.genai import types

from recouvrement.outils import executer_outil
from recouvrement.trace import Trace

TRACE: Trace | None = None      # injectee par executer(), pour garder les signatures nettes


def lister_factures_impayees(age_min_jours: int, exclure_litiges: bool = True) -> dict:
    """Liste les factures dont le retard atteint age_min_jours.

    Args:
        age_min_jours: retard minimal en jours, entre 0 et 365.
        exclure_litiges: si vrai, les factures en litige sont ecartees.
    """
    resultat = executer_outil("lister_factures_impayees",
                              {"age_min_jours": age_min_jours,
                               "exclure_litiges": exclure_litiges})
    if TRACE:
        TRACE.ecrire(evenement="appel_outil", outil="lister_factures_impayees",
                     ok=resultat.get("ok"))
    return resultat


def calculer_exposition(facture_ids: list[str]) -> dict:
    """Calcule la somme des montants des factures citees, en francs CFA.

    Args:
        facture_ids: identifiants au format FAC-000, deja connus du jeu de donnees.
    """
    resultat = executer_outil("calculer_exposition", {"facture_ids": facture_ids})
    if TRACE:
        TRACE.ecrire(evenement="appel_outil", outil="calculer_exposition",
                     ok=resultat.get("ok"))
    return resultat


def executer(trace: Trace, modele: str = "gemini-2.0-flash") -> str:
    global TRACE
    TRACE = trace
    client = genai.Client(api_key=os.environ["CLE_GENAI"])
    configuration = types.GenerateContentConfig(
        system_instruction=(
            "Tu analyses des factures impayees fictives. Utilise les outils pour lire "
            "et calculer. N'invente aucun montant. Aucune ecriture, aucun envoi."),
        temperature=0,
        max_output_tokens=600,
        # seules des lectures sont exposees : l'appel automatique executerait
        # immediatement toute fonction fournie ici.
        tools=[lister_factures_impayees, calculer_exposition],
    )
    reponse = client.models.generate_content(
        model=modele,
        contents="Prepare l'analyse des impayes de plus de 30 jours.",
        config=configuration)
    trace.ecrire(evenement="genai_termine",
                 jetons=getattr(reponse.usage_metadata, "total_token_count", 0))
    return reponse.text
