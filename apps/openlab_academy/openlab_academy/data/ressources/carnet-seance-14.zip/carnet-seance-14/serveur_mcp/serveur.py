"""Vos outils, publies en MCP. Installation : pip install "mcp[cli]"."""
import logging

from mcp.server.fastmcp import FastMCP

from recouvrement.outils import executer_outil

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
journal = logging.getLogger("serveur-recouvrement")

serveur = FastMCP("recouvrement")


@serveur.tool()
def lister_factures_impayees(age_min_jours: int = 30,
                             exclure_litiges: bool = True) -> dict:
    """Liste les factures impayees dont le retard atteint age_min_jours.

    Les montants sont en francs CFA. Les factures en litige sont ecartees par
    defaut et ne doivent jamais etre relancees. Les notes libres des factures ne
    sont jamais renvoyees. Lecture seule : cet outil n'ecrit rien.
    """
    journal.info("appel lister_factures_impayees age=%s", age_min_jours)
    return executer_outil("lister_factures_impayees",
                          {"age_min_jours": age_min_jours,
                           "exclure_litiges": exclure_litiges})


@serveur.tool()
def calculer_exposition(facture_ids: list[str]) -> dict:
    """Somme les montants des factures citees et renvoie le total en francs CFA.

    Les identifiants ont la forme FAC-000. Un identifiant inconnu fait echouer
    l'appel plutot que de produire un total partiel. Lecture seule.
    """
    journal.info("appel calculer_exposition n=%s", len(facture_ids))
    return executer_outil("calculer_exposition", {"facture_ids": facture_ids})


@serveur.resource("recouvrement://politique")
def politique_de_relance() -> str:
    """La politique interne de relance, offerte en lecture aux clients."""
    from pathlib import Path
    return Path("connaissances/politique_relance.md").read_text(encoding="utf-8")


# Ce qui n'est PAS publie, et pourquoi : preparer_brouillon_relance,
# soumettre_pour_validation et enregistrer_relance_simulee ecrivent. Un serveur partage
# est appele par des clients que vous ne controlez pas : l'ecriture reste chez vous,
# derriere votre validation humaine.

if __name__ == "__main__":
    serveur.run(transport="stdio")
