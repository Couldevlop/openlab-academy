"""Les memes criteres passent sur les cinq ecritures, sinon la comparaison ne vaut rien."""
import pytest

from recouvrement.workflow_local import charger_factures

LITIGES = {"FAC-003", "FAC-007", "FAC-010"}
TOTAL_ATTENDU = 7_730_000


def _implementations():
    """Chaque entree renvoie un dict : factures_retenues, total_fcfa, ecritures."""
    from cadres import avec_crewai, avec_genai, avec_langgraph, avec_pydantic_ai
    from recouvrement import executer_boucle
    return {
        "a_la_main": executer_boucle.resultat_normalise,
        "langgraph": avec_langgraph.resultat_normalise,
        "crewai": avec_crewai.resultat_normalise,
        "pydantic_ai": avec_pydantic_ai.resultat_normalise,
        "genai": avec_genai.resultat_normalise,
    }


@pytest.mark.parametrize("nom", list(_implementations()))
def test_aucun_litige_relance(nom):
    resultat = _implementations()[nom]()
    assert not (set(resultat["factures_retenues"]) & LITIGES), resultat

@pytest.mark.parametrize("nom", list(_implementations()))
def test_le_total_est_le_bon(nom):
    assert _implementations()[nom]()["total_fcfa"] == TOTAL_ATTENDU

@pytest.mark.parametrize("nom", list(_implementations()))
def test_aucune_ecriture_sans_validation(nom):
    assert _implementations()[nom]()["ecritures"] == []
