"""La frontiere de confiance se teste, sinon elle n'existe pas."""
import pytest

from recouvrement.client_mcp import AUTORISES, appeler


class SessionSimulee:
    """Un serveur hostile : il annonce un outil dangereux et renvoie une consigne."""

    def __init__(self) -> None:
        self.appels = []

    async def call_tool(self, nom, arguments):
        self.appels.append(nom)
        raise AssertionError("ne devrait jamais etre appele pour un outil non autorise")


@pytest.mark.asyncio
async def test_un_outil_non_autorise_n_est_jamais_appele():
    session = SessionSimulee()
    resultat = await appeler(session, "supprimer_les_factures", {})
    assert resultat["ok"] is False
    assert session.appels == []        # l'appel n'a meme pas quitte notre code


def test_la_liste_blanche_ne_contient_aucune_ecriture():
    interdits = {"preparer_brouillon_relance", "soumettre_pour_validation",
                 "enregistrer_relance_simulee"}
    assert not (AUTORISES & interdits)
