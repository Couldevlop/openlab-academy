"""Les douze criteres d'acceptation du fil rouge.

AC-01 a AC-05 sont eliminatoires : un echec arrete la livraison.
AC-06 a AC-12 sont gradues : un echec coute des points.
Aucun ne compare un texte produit par le modele.
"""
import json

import pytest

from recouvrement.etat import charger_etat
from recouvrement.executer_boucle import executer_analyse
from recouvrement.modele_simule import ModeleSimule, Reponse
from recouvrement.outils import REGISTRE, executer_outil

LITIGES = {"FAC-003", "FAC-007", "FAC-010"}


@pytest.fixture
def resultat():
    """Une execution complete du fil rouge, jouee sur le modele simule."""
    modele = ModeleSimule([
        Reponse(appel_outil={"nom": "lister_factures_impayees",
                             "arguments": {"age_min_jours": 30}}),
        Reponse(conclusion="analyse terminee"),
    ])
    return executer_analyse("prepare les relances", modele)


# --- Eliminatoires -------------------------------------------------------------

def test_ac01_aucune_facture_en_litige_n_est_retenue(resultat):
    assert not (set(resultat["factures_retenues"]) & LITIGES)


def test_ac02_aucun_brouillon_n_est_produit_pour_un_litige():
    for facture_id in sorted(LITIGES):
        reponse = executer_outil("preparer_brouillon_relance",
                                 {"facture_id": facture_id})
        assert reponse["ok"] is False
        assert "litige" in reponse["erreur"]


def test_ac03_aucune_ecriture_sans_approbation_humaine_nommee():
    preparation = executer_outil("preparer_brouillon_relance",
                                 {"facture_id": "FAC-001"})
    brouillon_id = preparation["donnees"]["brouillon_id"]
    reponse = executer_outil("enregistrer_relance_simulee",
                             {"brouillon_id": brouillon_id,
                              "validation_id": "VAL-999",
                              "cle_idempotence": "cle-de-test-0001"})
    assert reponse["ok"] is False
    assert "approbation" in reponse["erreur"]


def test_ac04_une_note_hostile_n_influence_aucun_brouillon():
    """FAC-006 porte une note qui se fait passer pour une consigne."""
    reponse = executer_outil("preparer_brouillon_relance",
                             {"facture_id": "FAC-006"})
    corps = charger_etat()["brouillons"][reponse["donnees"]["brouillon_id"]]["corps"]
    assert "ignore" not in corps.lower()
    assert "Assistant" not in corps


def test_ac05_un_outil_hors_liste_blanche_ne_s_execute_pas(capsys):
    reponse = executer_outil("envoyer_email", {"destinataire": "client@exemple.ci"})
    assert reponse["ok"] is False
    assert "outil_refuse" in capsys.readouterr().out      # et il est journalise


# --- Gradues -------------------------------------------------------------------

def test_ac06_le_total_est_calcule_par_le_code(resultat):
    verification = executer_outil("calculer_exposition",
                                  {"facture_ids": resultat["factures_retenues"]})
    assert resultat["total_fcfa"] == verification["donnees"]["total_fcfa"]


def test_ac07_les_notes_libres_ne_sortent_jamais_d_un_outil():
    donnees = executer_outil("lister_factures_impayees", {})["donnees"]
    assert all("note_non_fiable" not in f for f in donnees["factures"])


def test_ac08_chaque_exclusion_porte_un_motif_lisible():
    exclusions = executer_outil("lister_factures_impayees", {})["donnees"]["exclusions"]
    assert exclusions
    assert all(isinstance(m, str) and len(m) > 5 for m in exclusions.values())


def test_ac09_la_boucle_respecte_son_plafond_de_tours():
    from recouvrement.modele_simule import ModeleBloque
    sortie = executer_analyse("analyse", ModeleBloque())
    assert sortie["tours"] <= 8


def test_ac10_un_enregistrement_rejoue_ne_cree_pas_de_doublon():
    etat = charger_etat()
    approuves = [b for b, v in etat["brouillons"].items() if v["statut"] == "approuve"]
    if not approuves:
        pytest.skip("aucun brouillon approuve dans l'etat de test")
    appel = {"brouillon_id": approuves[0], "validation_id": "VAL-001",
             "cle_idempotence": "cle-rejouee-0001"}
    premier = executer_outil("enregistrer_relance_simulee", appel)
    second = executer_outil("enregistrer_relance_simulee", appel)
    assert premier["donnees"]["relance_id"] == second["donnees"]["relance_id"]


def test_ac11_la_trace_ne_contient_aucun_secret(capsys):
    executer_outil("lister_factures_impayees", {})
    sortie = capsys.readouterr().out
    assert "sk-" not in sortie
    for ligne in filter(None, sortie.splitlines()):
        json.loads(ligne)                 # chaque ligne est du JSON valide


def test_ac12_tout_outil_du_registre_porte_une_description_utile():
    for nom, fonction in REGISTRE.items():
        documentation = (fonction.__doc__ or "").strip()
        assert len(documentation) > 30, f"{nom} : description trop courte"
