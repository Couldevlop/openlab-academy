"""Le graphe se teste comme la boucle : un modele joue, aucun reseau."""
import pathlib

from langchain_core.messages import AIMessage, HumanMessage

from recouvrement.graphe_noeuds import faire_agir, prochaine_etape
from recouvrement.trace import Trace


def _message_avec_appel(nom, arguments):
    return AIMessage(content="", tool_calls=[
        {"name": nom, "args": arguments, "id": "appel-1", "type": "tool_call"}])


def test_l_arete_envoie_vers_la_validation_pour_une_ecriture():
    etat = {"messages": [_message_avec_appel("enregistrer_relance_simulee", {})],
            "brouillons": [], "jetons": 0, "statut": "en_cours"}
    assert prochaine_etape(etat) == "valider"


def test_l_arete_envoie_vers_l_outil_pour_une_lecture():
    etat = {"messages": [_message_avec_appel("lister_factures_impayees",
                                             {"age_min_jours": 30})],
            "brouillons": [], "jetons": 0, "statut": "en_cours"}
    assert prochaine_etape(etat) == "agir"


def test_le_budget_termine_le_graphe():
    etat = {"messages": [_message_avec_appel("lister_factures_impayees", {})],
            "brouillons": [], "jetons": 99_000, "statut": "en_cours"}
    assert prochaine_etape(etat) == "fin"


def test_le_noeud_agir_passe_par_la_liste_blanche(tmp_path):
    agir = faire_agir(Trace(pathlib.Path(tmp_path) / "t.jsonl"))
    etat = {"messages": [_message_avec_appel("supprimer_facture", {"facture_id": "FAC-001"})],
            "brouillons": [], "jetons": 0, "statut": "en_cours"}
    sortie = agir(etat)
    assert "ok" in sortie["messages"][0].content      # refus lisible, pas d'exception
