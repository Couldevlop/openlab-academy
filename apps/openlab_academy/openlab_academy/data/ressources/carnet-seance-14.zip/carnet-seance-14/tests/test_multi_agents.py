"""Les trois pannes propres au multi-agents, chacune avec son test."""
import pytest

from multi.contrats_echange import OrdreDeMission, Rapport
from multi.superviseur import _agreger, _decouper
from recouvrement.trace import Trace


def ordre(factures):
    return OrdreDeMission(mission_id="MIS-001", objectif="preparer les brouillons",
                          factures=factures)


def test_les_lots_sont_disjoints_et_couvrent_tout():
    factures = [f"FAC-{i:03d}" for i in range(1, 11)]
    lots = _decouper(factures)
    assert [f for lot in lots for f in lot] == factures
    assert sum(len(lot) for lot in lots) == len(set(factures))


def test_un_specialiste_en_erreur_n_arrete_pas_les_autres():
    ordres = [ordre(["FAC-001"]), ordre(["FAC-004"])]
    rapports = [RuntimeError("panne"),
                Rapport(mission_id="MIS-001", reussi=True, brouillons=["BRO-001"])]
    resultat = _agreger(ordres, rapports, Trace())
    assert resultat["brouillons"] == ["BRO-001"]
    assert "FAC-001" in resultat["factures_non_traitees"]


def test_un_rapport_incoherent_est_refuse_et_pas_agrege():
    incoherent = Rapport(mission_id="MIS-001", reussi=True, brouillons=[])
    assert not incoherent.est_coherent()
    resultat = _agreger([ordre(["FAC-001"])], [incoherent], Trace())
    assert resultat["brouillons"] == []
    assert resultat["factures_non_traitees"] == ["FAC-001"]


def test_une_facture_ecartee_remonte_nommement():
    rapport = Rapport(mission_id="MIS-001", reussi=True, brouillons=["BRO-001"],
                      factures_non_traitees=["FAC-003"])
    resultat = _agreger([ordre(["FAC-001", "FAC-003"])], [rapport], Trace())
    assert resultat["factures_non_traitees"] == ["FAC-003"]
