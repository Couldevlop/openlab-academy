"""Fusionne recherche lexicale et recherche vectorielle, sans reglage a trouver."""
from typing import Protocol

from recouvrement.corpus import Passage
from recouvrement.index_lexical import IndexLexical

CONSTANTE_RANG = 60      # amortit l'ecart entre les premiers rangs


class Chercheur(Protocol):
    def chercher(self, question: str, k: int = 5) -> list[tuple[Passage, float]]:
        ...


def fusionner(listes: list[list[tuple[Passage, float]]], k: int = 5
              ) -> list[tuple[Passage, float]]:
    scores: dict[str, float] = {}
    vus: dict[str, Passage] = {}
    for liste in listes:
        for rang, (passage, _) in enumerate(liste, start=1):
            scores[passage.identifiant] = scores.get(passage.identifiant, 0.0) + \
                1 / (CONSTANTE_RANG + rang)
            vus[passage.identifiant] = passage
    classes = sorted(scores.items(), key=lambda couple: couple[1], reverse=True)
    return [(vus[identifiant], round(score, 5)) for identifiant, score in classes[:k]]


class RechercheHybride:
    def __init__(self, lexical: IndexLexical, vectoriel: Chercheur | None = None) -> None:
        self.lexical = lexical
        self.vectoriel = vectoriel      # absent : la fusion marche quand meme

    def chercher(self, question: str, k: int = 5) -> list[tuple[Passage, float]]:
        listes = [self.lexical.chercher(question, k=k * 2)]
        if self.vectoriel is not None:
            listes.append(self.vectoriel.chercher(question, k=k * 2))
        return fusionner(listes, k=k)
