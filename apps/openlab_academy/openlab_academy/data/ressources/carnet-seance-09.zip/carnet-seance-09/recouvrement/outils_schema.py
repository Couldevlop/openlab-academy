"""Traduit la liste blanche en descriptions d'outils pour le modele."""
import json
import pathlib
from typing import Any

CONTRATS = pathlib.Path("contracts/contrats_outils.json")


def charger_contrats() -> list[dict[str, Any]]:
    donnees = json.loads(CONTRATS.read_text(encoding="utf-8"))
    return donnees["tools"]


def pour_le_modele(noms_autorises) -> list[dict[str, Any]]:
    """Un outil non autorise n'est pas decrit : le modele ne peut pas demander
    ce qu'il ne voit pas, et le point d'appel refuse de toute facon.

    On accepte un ensemble de noms comme le registre lui-meme : set() rend les
    deux equivalents, et evite un appel qui echoue pour une question de type."""
    noms = set(noms_autorises)
    decrits = []
    for contrat in charger_contrats():
        if contrat["name"] not in noms:
            continue
        decrits.append({
            "type": "function",
            "function": {
                "name": contrat["name"],
                "description": contrat["description"],
                "parameters": contrat["input_schema"],
            },
        })
    manquants = noms - {c["name"] for c in charger_contrats()}
    if manquants:
        raise RuntimeError(f"outils autorises sans contrat : {sorted(manquants)}")
    return decrits
