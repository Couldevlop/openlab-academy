"""Reprendre une execution interrompue sans refaire ce qui est deja fait."""
import hashlib

from recouvrement.etat import charger_etat, enregistrer_etat


def cle_idempotence(brouillon_id: str, facture_id: str, palier: int) -> str:
    """Construite sur l'intention, jamais sur l'heure : sinon elle ne protege rien."""
    graine = f"{brouillon_id}|{facture_id}|{palier}"
    return hashlib.sha256(graine.encode("utf-8")).hexdigest()[:32]


def demarrer_execution(execution_id: str, consigne: str) -> None:
    etat = charger_etat()
    etat["executions"].append({"execution_id": execution_id, "consigne": consigne,
                               "statut": "en_cours", "etapes_faites": []})
    enregistrer_etat(etat)


def marquer_etape(execution_id: str, etape: str) -> None:
    """Ecrit apres l'action : une etape marquee est une etape reellement faite."""
    etat = charger_etat()
    for execution in etat["executions"]:
        if execution["execution_id"] == execution_id:
            execution["etapes_faites"].append(etape)
            break
    enregistrer_etat(etat)


def etapes_deja_faites(execution_id: str) -> set[str]:
    etat = charger_etat()
    for execution in etat["executions"]:
        if execution["execution_id"] == execution_id:
            return set(execution["etapes_faites"])
    return set()


def executions_interrompues() -> list[dict]:
    """Ce que l'exploitant regarde apres un redemarrage."""
    return [e for e in charger_etat()["executions"] if e["statut"] == "en_cours"]


def cloturer_execution(execution_id: str, conclusion: str) -> None:
    etat = charger_etat()
    for execution in etat["executions"]:
        if execution["execution_id"] == execution_id:
            execution["statut"] = "terminee"
            execution["conclusion"] = conclusion
    enregistrer_etat(etat)
