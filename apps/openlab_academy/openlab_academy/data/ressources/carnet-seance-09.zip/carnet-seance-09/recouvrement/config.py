"""Reglages lus dans l'environnement. Aucun secret n'est ecrit dans le code."""
import os
from dataclasses import dataclass


class ConfigurationManquante(RuntimeError):
    """Un reglage obligatoire est absent : on s'arrete tout de suite, pas en plein vol."""


def exiger(nom: str) -> str:
    valeur = os.environ.get(nom, "").strip()
    if not valeur:
        raise ConfigurationManquante(
            f"variable {nom} absente : copiez .env.example vers .env et remplissez-la")
    return valeur


def entier(nom: str, defaut: int, minimum: int, maximum: int) -> int:
    brut = os.environ.get(nom, "").strip()
    if not brut:
        return defaut
    try:
        valeur = int(brut)
    except ValueError:
        raise ConfigurationManquante(f"{nom} doit etre un entier, recu {brut!r}") from None
    if not minimum <= valeur <= maximum:
        raise ConfigurationManquante(f"{nom} doit etre entre {minimum} et {maximum}")
    return valeur


@dataclass(frozen=True)
class Reglages:
    modele: str
    cle: str
    adresse: str | None       # None = service par defaut du fournisseur
    tours_max: int
    jetons_max: int
    budget_jetons: int        # plafond pour une execution complete

    @classmethod
    def depuis_environnement(cls) -> "Reglages":
        return cls(
            modele=os.environ.get("MODELE", "gpt-4o-mini"),
            cle=exiger("CLE_MODELE"),
            adresse=os.environ.get("ADRESSE_MODELE") or None,
            tours_max=entier("TOURS_MAX", 8, 1, 30),
            jetons_max=entier("JETONS_MAX", 600, 50, 4000),
            budget_jetons=entier("BUDGET_JETONS", 60_000, 1_000, 2_000_000),
        )
