"""Lit le dossier connaissances et le decoupe en passages citables."""
import pathlib
import re
from dataclasses import dataclass

DOSSIER = pathlib.Path("connaissances")
TITRE_SECTION = re.compile(r"^##\s+(.+)$", re.MULTILINE)


@dataclass(frozen=True)
class Passage:
    identifiant: str      # ex. politique_relance#paliers
    document: str
    section: str
    texte: str

    @property
    def citable(self) -> str:
        return f"{self.document} / {self.section}"


def _identifiant(document: str, section: str) -> str:
    ancre = re.sub(r"[^a-z0-9]+", "-", section.lower()).strip("-")
    return f"{document}#{ancre}"


def decouper(dossier: pathlib.Path = DOSSIER) -> list[Passage]:
    passages: list[Passage] = []
    for fichier in sorted(dossier.glob("*.md")):
        contenu = fichier.read_text(encoding="utf-8")
        document = fichier.stem
        decoupes = TITRE_SECTION.split(contenu)
        # split renvoie [avant, titre1, corps1, titre2, corps2, ...]
        for titre, corps in zip(decoupes[1::2], decoupes[2::2]):
            texte = corps.strip()
            if not texte:
                continue
            passages.append(Passage(
                identifiant=_identifiant(document, titre),
                document=document, section=titre.strip(),
                # le titre est recopie dans le texte : le passage se comprend seul
                texte=f"{titre.strip()}. {texte}"))
    if not passages:
        raise RuntimeError(f"aucun passage trouve dans {dossier}")
    return passages
