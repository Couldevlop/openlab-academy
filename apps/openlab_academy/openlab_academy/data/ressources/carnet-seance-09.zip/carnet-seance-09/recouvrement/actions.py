"""Le code metier derriere la porte. Trois regles y sont en dur, et c'est voulu."""
import hashlib
from datetime import date

from recouvrement.domaine import Brouillon, exposition, montant_lisible
from recouvrement.donnees import charger_factures
from recouvrement.etat import charger_etat, enregistrer_etat


class ErreurMetier(Exception):
    """Une erreur attendue, destinee a etre lue par le modele."""


def lister_factures_impayees(age_min_jours: int = 30,
                             exclure_litiges: bool = True) -> dict:
    """Liste les factures dont le retard atteint le seuil demande, litiges exclus
    par defaut. Renvoie les retenues et, nommement, les exclues avec leur motif."""
    retenues, exclues = [], {}
    for f in charger_factures():
        if exclure_litiges and f.en_litige:
            exclues[f.facture_id] = "litige en cours"
            continue
        if f.retard_jours < age_min_jours:
            exclues[f.facture_id] = f"retard de {f.retard_jours} jours"
            continue
        # La note libre n'est jamais renvoyee : c'est une donnee de tiers.
        retenues.append({"facture_id": f.facture_id, "client_ref": f.client_ref,
                         "montant_fcfa": f.montant_fcfa,
                         "retard_jours": f.retard_jours,
                         "palier_suivant": f.palier_suivant()})
    return {"factures": retenues, "exclusions": exclues,
            "nombre": len(retenues)}


def calculer_exposition(facture_ids: list[str]) -> dict:
    """Additionne les montants des factures citees. Le total vient du code et
    jamais du modele : c'est le critere AC-06."""
    connues = {f.facture_id: f for f in charger_factures()}
    inconnues = [i for i in facture_ids if i not in connues]
    if inconnues:
        raise ErreurMetier(f"identifiants inconnus : {', '.join(inconnues)}")
    total = exposition([connues[i] for i in facture_ids])
    return {"total_fcfa": total, "total_lisible": montant_lisible(total),
            "nombre_factures": len(facture_ids)}


def preparer_brouillon_relance(facture_id: str, palier: int = 1) -> dict:
    """Prepare un brouillon de relance pour une facture eligible. Un litige, un
    retard insuffisant ou un palier epuise font echouer l'appel, sans ecriture."""
    facture = next((f for f in charger_factures() if f.facture_id == facture_id), None)
    if facture is None:
        raise ErreurMetier(f"facture inconnue : {facture_id}")
    # Regle en dur numero 1 : le litige bloque, quelle que soit la consigne recue.
    if facture.en_litige:
        raise ErreurMetier(f"{facture_id} est en litige : aucune relance possible")
    objets = {1: "Rappel amiable", 2: "Relance ferme", 3: "Mise en demeure"}
    # Regle en dur numero 2 : aucune note libre de la facture n'entre dans le texte.
    corps = (f"Bonjour,\n\nSauf erreur de notre part, la facture {facture.facture_id} "
             f"d'un montant de {montant_lisible(facture.montant_fcfa)} reste impayee "
             f"depuis {facture.retard_jours} jours.\n\nNous vous remercions de "
             f"proceder au reglement.\n\nCordialement,")
    etat = charger_etat()
    brouillon = Brouillon(
        brouillon_id=f"BRO-{len(etat['brouillons']) + 1:03d}",
        facture_id=facture.facture_id, palier=palier,
        objet=f"{objets[palier]} - {facture.facture_id}",
        corps=corps, cree_le=date.today())
    etat["brouillons"][brouillon.brouillon_id] = {
        "facture_id": brouillon.facture_id, "palier": palier,
        "objet": brouillon.objet, "corps": corps, "statut": "prepare"}
    enregistrer_etat(etat)
    return {"brouillon_id": brouillon.brouillon_id, "objet": brouillon.objet}


def soumettre_pour_validation(brouillon_id: str, commentaire: str = "") -> dict:
    """Soumet un brouillon a une validation humaine nommee. Rien ne part a ce
    stade : la soumission cree une demande, pas un envoi."""
    etat = charger_etat()
    brouillon = etat["brouillons"].get(brouillon_id)
    if brouillon is None:
        raise ErreurMetier(f"brouillon inconnu : {brouillon_id}")
    brouillon["statut"] = "en_attente"
    brouillon["commentaire"] = commentaire[:300]
    enregistrer_etat(etat)
    return {"brouillon_id": brouillon_id, "statut": "en_attente"}


def enregistrer_relance_simulee(brouillon_id: str, validation_id: str,
                                cle_idempotence: str) -> dict:
    """Enregistre une relance simulee, apres approbation seulement. Aucun courriel
    n'est emis : l'ecriture reste locale, idempotente et tracee."""
    etat = charger_etat()
    brouillon = etat["brouillons"].get(brouillon_id)
    if brouillon is None:
        raise ErreurMetier(f"brouillon inconnu : {brouillon_id}")
    # Regle en dur numero 3 : aucune ecriture sans approbation humaine nommee.
    # Le validation_id est produit par une personne : l'agent ne peut pas l'inventer.
    if etat["validations"].get(validation_id, {}).get("brouillon_id") != brouillon_id:
        raise ErreurMetier("enregistrement refuse : approbation humaine manquante")
    empreinte = hashlib.sha256(cle_idempotence.encode()).hexdigest()[:16]
    if empreinte in etat["idempotence"]:
        return {"relance_id": etat["idempotence"][empreinte], "rejouee": True}
    relance_id = f"REL-{len(etat['relances']) + 1:03d}"
    etat["relances"].append({"relance_id": relance_id, "brouillon_id": brouillon_id,
                             "validation_id": validation_id,
                             "valideur": etat["validations"][validation_id]["valideur"]})
    etat["idempotence"][empreinte] = relance_id
    brouillon["statut"] = "enregistre"
    enregistrer_etat(etat)
    return {"relance_id": relance_id, "rejouee": False}


def chercher_dans_les_connaissances(question: str, nombre_passages: int = 3) -> dict:
    """Implemente en seance 9 ; ici, la signature suffit a figer le contrat."""
    raise ErreurMetier("recherche documentaire disponible a partir de la seance 9")
