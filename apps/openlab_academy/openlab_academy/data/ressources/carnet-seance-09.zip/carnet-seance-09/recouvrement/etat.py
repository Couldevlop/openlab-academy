"""L'etat durable. Regle unique : jamais de fichier a moitie ecrit."""
import json
import os
import pathlib
import tempfile
import threading

CHEMIN = pathlib.Path(os.environ.get("ETAT_CHEMIN", "donnees/etat.json"))
VERSION = 2
_VERROU = threading.Lock()


def etat_vide() -> dict:
    return {"version": VERSION, "brouillons": {}, "relances": [],
            "validations": {}, "idempotence": {}, "executions": []}


def charger_etat() -> dict:
    """Un etat absent n'est pas une erreur : c'est un premier demarrage."""
    if not CHEMIN.exists():
        return etat_vide()
    try:
        donnees = json.loads(CHEMIN.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        # Fichier corrompu : on le met de cote au lieu de l'ecraser en silence.
        CHEMIN.rename(CHEMIN.with_suffix(".corrompu"))
        return etat_vide()
    return _migrer(donnees)


def _migrer(donnees: dict) -> dict:
    """Le format evolue ; les anciens fichiers doivent continuer a s'ouvrir."""
    if donnees.get("version", 1) < 2:
        donnees.setdefault("executions", [])
        donnees.setdefault("validations", {})
        donnees["version"] = 2
    return donnees


def enregistrer_etat(etat: dict) -> None:
    """Ecriture atomique : temporaire, vidage force, remplacement en une operation."""
    CHEMIN.parent.mkdir(parents=True, exist_ok=True)
    with _VERROU:
        descripteur, temporaire = tempfile.mkstemp(dir=str(CHEMIN.parent),
                                                   suffix=".tmp")
        try:
            with os.fdopen(descripteur, "w", encoding="utf-8") as fichier:
                json.dump(etat, fichier, ensure_ascii=False, indent=2)
                fichier.flush()
                os.fsync(fichier.fileno())   # sans cela, le systeme peut differer
            os.replace(temporaire, CHEMIN)   # atomique sur Windows comme sur Linux
        except BaseException:
            pathlib.Path(temporaire).unlink(missing_ok=True)
            raise
