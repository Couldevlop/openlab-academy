"""Le contrat entre la boucle et n'importe quel modele. Aucun import de fournisseur ici."""
from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class AppelOutil:
    nom: str
    arguments: dict[str, Any]


@dataclass(frozen=True)
class Conclusion:
    texte: str


Decision = AppelOutil | Conclusion


@dataclass(frozen=True)
class Usage:
    """Ce qu'un appel a coute : indispensable pour le budget et pour la trace."""
    jetons_entree: int
    jetons_sortie: int

    @property
    def total(self) -> int:
        return self.jetons_entree + self.jetons_sortie


@dataclass(frozen=True)
class Reponse:
    decision: Decision
    usage: Usage


class Modele(Protocol):
    """Tout objet qui sait decider est un modele, quel que soit son fournisseur."""

    def decider(self, historique: list[dict[str, Any]],
                outils: list[dict[str, Any]]) -> Reponse:
        ...


class ModeleIndisponible(RuntimeError):
    """Panne du cote du modele : reseau, quota, service. Distincte d'une erreur d'outil."""
