"""Le squelette de l'agent : les quatre composants, et rien d'autre."""
from dataclasses import dataclass, field
from typing import Protocol

from recouvrement.domaine import Brouillon, Facture


class Modele(Protocol):
    """Le composant 1 : le raisonnement. Un protocole, pas une classe concrete,
    pour qu'un modele simule suffise aux tests."""

    def decider(self, consigne: str, observations: list[str]) -> str: ...


class Outils(Protocol):
    """Le composant 2 : les actions. Rien ne s'execute hors de cette porte."""

    def executer(self, nom: str, arguments: dict) -> dict: ...


@dataclass
class Memoire:
    """Le composant 3 : la memoire de travail d'une execution."""
    observations: list[str] = field(default_factory=list)
    factures: list[Facture] = field(default_factory=list)
    brouillons: list[Brouillon] = field(default_factory=list)

    def noter(self, observation: str) -> None:
        self.observations.append(observation)


@dataclass
class Garde:
    """Le composant 4 : les limites. Sans elles, la boucle ne s'arrete pas."""
    tours_maximum: int = 8
    budget_fcfa: int = 500
    depense_fcfa: int = 0

    def autorise(self, tour: int) -> bool:
        return tour < self.tours_maximum and self.depense_fcfa < self.budget_fcfa


def executer(consigne: str, modele: Modele, outils: Outils,
             memoire: Memoire | None = None, garde: Garde | None = None) -> Memoire:
    """Les dependances entrent par les parametres : c'est ce qui rend l'agent testable.

    La boucle elle-meme est ecrite en seance 6 ; ici, seule la forme compte.
    """
    memoire = memoire or Memoire()
    garde = garde or Garde()
    tour = 0
    while garde.autorise(tour):
        decision = modele.decider(consigne, memoire.observations)
        if decision == "conclure":
            break
        memoire.noter(f"tour {tour} : {decision}")   # seance 6 : l'appel d'outil reel
        tour += 1
    return memoire
