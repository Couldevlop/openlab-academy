"""Vecteurs calcules une fois et ranges dans un fichier. Optionnel : le lexical suffit
pour demarrer, et cette classe s'ajoute sans toucher au reste."""
import json
import math
import pathlib

from recouvrement.corpus import Passage

CACHE = pathlib.Path(".local/vecteurs.json")


def _cosinus(a: list[float], b: list[float]) -> float:
    produit = sum(x * y for x, y in zip(a, b))
    norme = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
    return produit / norme if norme else 0.0


class IndexVectoriel:
    def __init__(self, passages: list[Passage], plonger) -> None:
        """plonger(textes) -> liste de vecteurs ; fourni par votre adaptateur de modele,
        local ou distant. L'index ne sait pas qui calcule."""
        self.passages = passages
        self.plonger = plonger
        self.vecteurs = self._charger_ou_calculer()

    def _charger_ou_calculer(self) -> list[list[float]]:
        cles = [p.identifiant for p in self.passages]
        if CACHE.exists():
            cache = json.loads(CACHE.read_text(encoding="utf-8"))
            if cache.get("cles") == cles:          # le corpus n'a pas bouge
                return cache["vecteurs"]
        vecteurs = self.plonger([p.texte for p in self.passages])
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(json.dumps({"cles": cles, "vecteurs": vecteurs}),
                         encoding="utf-8")
        return vecteurs

    def chercher(self, question: str, k: int = 5) -> list[tuple[Passage, float]]:
        cible = self.plonger([question])[0]
        scores = [(self.passages[i], round(_cosinus(cible, v), 4))
                  for i, v in enumerate(self.vecteurs)]
        scores.sort(key=lambda couple: couple[1], reverse=True)
        return scores[:k]
