"""Une ligne JSON par evenement. Ce qui ne doit jamais sortir est filtre ici."""
import json
import pathlib
import uuid
from datetime import datetime, timezone

INTERDITS = {"cle", "api_key", "authorization", "note_non_fiable", "mot_de_passe"}


def _filtrer(valeur):
    if isinstance(valeur, dict):
        return {c: ("[retire]" if c.lower() in INTERDITS else _filtrer(v))
                for c, v in valeur.items()}
    if isinstance(valeur, list):
        return [_filtrer(v) for v in valeur]
    return valeur


class Trace:
    """Sans chemin, la trace part sur la sortie standard : c'est le mode atelier des
    seances 5 et 6. Avec un chemin, elle devient le journal de production."""

    def __init__(self, chemin: pathlib.Path | None = None) -> None:
        self.chemin = chemin
        if self.chemin is not None:
            self.chemin.parent.mkdir(parents=True, exist_ok=True)

    def nouvelle_execution(self) -> str:
        """Un identifiant court, qui relie entre elles les lignes d'une meme execution."""
        return uuid.uuid4().hex[:12]

    def ecrire(self, execution_id: str | None = None, evenement: str | None = None,
               **champs) -> None:
        ligne = {"horodatage": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                 "execution_id": execution_id, "evenement": evenement,
                 **_filtrer(champs)}
        texte = json.dumps({c: v for c, v in ligne.items() if v is not None},
                           ensure_ascii=False)
        if self.chemin is None:
            print(texte)          # mode atelier : la trace se lit dans le terminal
            return
        with self.chemin.open("a", encoding="utf-8") as fichier:
            fichier.write(texte + "\n")
