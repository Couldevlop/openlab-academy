"""Adaptateur pour un moteur local (Ollama, llama.cpp). Meme interface, zero budget."""
from typing import Any

from recouvrement.config import Reglages
from recouvrement.modele_distant import ModeleDistant
from recouvrement.modele import Reponse, Usage


class ModeleLocal(ModeleDistant):
    """Le moteur local imite la meme interface : seule l'adresse change, et l'usage
    peut manquer. On herite donc, et on ne redefinit que ce qui differe."""

    def __init__(self, reglages: Reglages) -> None:
        local = Reglages(
            modele=reglages.modele,
            cle="locale-sans-objet",                  # le moteur local n'en demande pas
            adresse=reglages.adresse or "http://localhost:11434/v1",
            tours_max=reglages.tours_max,
            jetons_max=reglages.jetons_max,
            budget_jetons=reglages.budget_jetons,
        )
        super().__init__(local)

    def decider(self, historique: list[dict[str, Any]],
                outils: list[dict[str, Any]]) -> Reponse:
        reponse = super().decider(historique, outils)
        if reponse.usage.total == 0:                  # certains moteurs ne le renvoient pas
            estime = sum(len(str(m)) for m in historique) // 4
            return Reponse(reponse.decision, Usage(jetons_entree=estime, jetons_sortie=0))
        return reponse
