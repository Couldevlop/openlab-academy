"""Recherche lexicale BM25, sans dependance : un mot rare vaut plus qu'un mot courant."""
import math
import re
from collections import Counter

from recouvrement.corpus import Passage

MOT = re.compile(r"\w+")          # \w couvre les lettres accentuees
K = 1.5      # rendement decroissant des repetitions
B = 0.75     # penalite de longueur


def mots(texte: str) -> list[str]:
    """Minuscules, et un pluriel simple ramene au singulier : sans cela,
    'montants' et 'montant' ne se rencontrent jamais."""
    bruts = [m.group(0).lower() for m in MOT.finditer(texte)]
    return [mot[:-1] if len(mot) > 3 and mot.endswith("s") else mot for mot in bruts]


class IndexLexical:
    def __init__(self, passages: list[Passage]) -> None:
        self.passages = passages
        self.sacs = [Counter(mots(p.texte)) for p in passages]
        self.longueurs = [sum(sac.values()) for sac in self.sacs]
        self.longueur_moyenne = sum(self.longueurs) / len(self.sacs)
        presence = Counter()
        for sac in self.sacs:
            presence.update(sac.keys())
        total = len(self.sacs)
        # rarete d'un mot : un mot present partout n'aide pas a departager
        self.rarete = {mot: math.log(1 + (total - n + 0.5) / (n + 0.5))
                       for mot, n in presence.items()}

    def chercher(self, question: str, k: int = 5) -> list[tuple[Passage, float]]:
        demandes = mots(question)
        scores = []
        for indice, sac in enumerate(self.sacs):
            score = 0.0
            longueur = self.longueurs[indice] or 1
            for mot in demandes:
                frequence = sac.get(mot, 0)
                if not frequence:
                    continue
                norme = 1 - B + B * longueur / self.longueur_moyenne
                score += self.rarete.get(mot, 0.0) * frequence * (K + 1) / (
                    frequence + K * norme)
            if score > 0:
                scores.append((self.passages[indice], round(score, 4)))
        scores.sort(key=lambda couple: couple[1], reverse=True)
        return scores[:k]
