"""Sixieme outil : consulter les procedures internes, en citant ses sources."""
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from recouvrement.recherche import RechercheHybride

EXTRAIT_MAX = 500      # un passage long est tronque : le contexte se paie


class ArgumentsRecherche(BaseModel):
    # Les memes noms que le contrat JSON et que contrats.py : un seul vocabulaire.
    question: str = Field(min_length=3, max_length=300)
    nombre_passages: int = Field(default=3, ge=1, le=5)


def chercher_procedure(recherche: RechercheHybride, **bruts: Any) -> dict:
    try:
        args = ArgumentsRecherche(**bruts)
    except ValidationError as erreur:
        return {"ok": False, "erreur": "Arguments invalides",
                "details": erreur.errors(include_url=False)}
    trouves = recherche.chercher(args.question, k=args.nombre_passages)
    if not trouves:
        # dire qu'on n'a rien trouve vaut mieux que renvoyer le moins mauvais passage
        return {"ok": True, "donnees": {"passages": []},
                "message": "aucune procedure ne repond"}
    # Meme forme de reponse que les cinq autres outils : ok, puis donnees.
    return {"ok": True, "donnees": {"passages": [
        {"identifiant": passage.identifiant,
         "source": passage.citable,
         "extrait": passage.texte[:EXTRAIT_MAX],
         "score": score}
        for passage, score in trouves]}}
