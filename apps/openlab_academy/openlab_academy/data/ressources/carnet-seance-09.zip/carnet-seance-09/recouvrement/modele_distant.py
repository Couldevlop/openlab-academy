"""Adaptateur pour un fournisseur distant. Le seul fichier qui connait son interface."""
import json
import random
import time
from typing import Any

from openai import OpenAI, APIError, APITimeoutError, RateLimitError

from recouvrement.config import Reglages
from recouvrement.modele import (AppelOutil, Conclusion, ModeleIndisponible,
                                 Reponse, Usage)


class ModeleDistant:
    def __init__(self, reglages: Reglages) -> None:
        self._reglages = reglages
        self._client = OpenAI(api_key=reglages.cle, base_url=reglages.adresse,
                              timeout=30.0, max_retries=0)   # nos relances, pas les siennes

    def decider(self, historique: list[dict[str, Any]],
                outils: list[dict[str, Any]]) -> Reponse:
        brut = self._appeler_avec_une_relance(historique, outils)
        message = brut.choices[0].message
        usage = Usage(jetons_entree=brut.usage.prompt_tokens,
                      jetons_sortie=brut.usage.completion_tokens)
        if not message.tool_calls:
            return Reponse(Conclusion(message.content or ""), usage)
        appel = message.tool_calls[0]
        try:
            arguments = json.loads(appel.function.arguments or "{}")
        except json.JSONDecodeError:
            # le modele a produit des arguments illisibles : c'est une decision invalide,
            # pas une panne ; la boucle la traitera comme un refus d'outil.
            arguments = {"__illisible__": appel.function.arguments}
        return Reponse(AppelOutil(appel.function.name, arguments), usage)

    def _appeler_avec_une_relance(self, historique, outils):
        for tentative in (0, 1):
            try:
                return self._client.chat.completions.create(
                    model=self._reglages.modele,
                    messages=historique,
                    tools=outils,
                    tool_choice="auto",
                    temperature=0,
                    max_tokens=self._reglages.jetons_max,
                )
            except (APITimeoutError, RateLimitError) as erreur:
                if tentative == 1:
                    raise ModeleIndisponible(f"modele injoignable : {erreur!r}") from erreur
                time.sleep(1.5 + random.random())   # une seule attente, legerement aleatoire
            except APIError as erreur:
                raise ModeleIndisponible(f"erreur du fournisseur : {erreur!r}") from erreur
