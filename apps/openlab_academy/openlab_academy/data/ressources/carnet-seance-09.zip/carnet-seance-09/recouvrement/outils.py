"""La porte unique des actions. Rien ne s'execute en dehors d'executer_outil."""
import time
from typing import Any, Callable

from pydantic import ValidationError

from recouvrement import actions
from recouvrement.contrats import CONTRATS
from recouvrement.trace import Trace

# La liste blanche : un outil absent d'ici n'existe pas, quoi que demande le modele.
REGISTRE: dict[str, Callable[..., Any]] = {
    "lister_factures_impayees": actions.lister_factures_impayees,
    "calculer_exposition": actions.calculer_exposition,
    "preparer_brouillon_relance": actions.preparer_brouillon_relance,
    "soumettre_pour_validation": actions.soumettre_pour_validation,
    "enregistrer_relance_simulee": actions.enregistrer_relance_simulee,
    "chercher_dans_les_connaissances": actions.chercher_dans_les_connaissances,
}


def executer_outil(nom: str, arguments: dict, trace: Trace | None = None) -> dict:
    """Refuser, valider, executer, journaliser. Dans cet ordre, toujours."""
    debut = time.perf_counter()
    trace = trace or Trace()

    # 1. Refuser : un outil hors liste blanche est journalise, pas seulement refuse.
    if nom not in REGISTRE:
        trace.ecrire(evenement="outil_refuse", outil=nom, motif="hors_liste_blanche")
        return {"ok": False, "erreur": "outil inconnu",
                "outils_disponibles": sorted(REGISTRE)}

    # 2. Valider : le contrat refuse avant que le code metier ne voie quoi que ce soit.
    try:
        valides = CONTRATS[nom](**arguments).model_dump()
    except ValidationError as erreur:
        detail = "; ".join(f"{'.'.join(map(str, e['loc']))}: {e['msg']}"
                           for e in erreur.errors()[:3])
        trace.ecrire(evenement="arguments_refuses", outil=nom, detail=detail)
        return {"ok": False, "erreur": f"arguments invalides : {detail}"}

    # 3. Executer : une erreur metier est une reponse, pas un plantage.
    try:
        donnees = REGISTRE[nom](**valides)
        resultat = {"ok": True, "donnees": donnees}
    except actions.ErreurMetier as erreur:
        resultat = {"ok": False, "erreur": str(erreur)}
    except Exception as erreur:                       # noqa: BLE001
        # Inattendu : on n'expose pas la trace interne au modele.
        trace.ecrire(evenement="erreur_interne", outil=nom, type=type(erreur).__name__)
        resultat = {"ok": False, "erreur": "erreur interne, reessayez autrement"}

    # 4. Journaliser : toujours, succes comme echec.
    trace.ecrire(evenement="appel_outil", outil=nom, ok=resultat["ok"],
                 duree_ms=round((time.perf_counter() - debut) * 1000, 1))
    return resultat
