"""Le coeur metier : des objets et des regles, aucun appel reseau, aucun modele."""
from dataclasses import dataclass
from datetime import date


SEUIL_RELANCE_JOURS = 30          # au-dela, une facture devient relancable
MONTANT_PLANCHER_FCFA = 500_000   # en dessous, la relance coute plus qu'elle ne rapporte
PALIER_MAXIMUM = 3                # apres trois relances, le dossier passe en recouvrement


@dataclass(frozen=True)
class Facture:
    """Immuable : une facture ne change pas sous vos pieds pendant un traitement."""
    facture_id: str
    client_ref: str
    montant_fcfa: int
    retard_jours: int
    en_litige: bool
    dernier_palier: int
    note_non_fiable: str = ""      # donnee, jamais consigne : voir la seance 15

    def est_relancable(self) -> bool:
        """La seule definition de l'eligibilite, dans tout le projet."""
        return (not self.en_litige
                and self.retard_jours >= SEUIL_RELANCE_JOURS
                and self.montant_fcfa >= MONTANT_PLANCHER_FCFA
                and self.dernier_palier < PALIER_MAXIMUM)

    def motif_exclusion(self) -> str | None:
        """Pourquoi cette facture n'est pas relancee : une phrase, pour l'humain."""
        if self.en_litige:
            return "litige en cours"
        if self.retard_jours < SEUIL_RELANCE_JOURS:
            return f"retard de {self.retard_jours} jours, seuil a {SEUIL_RELANCE_JOURS}"
        if self.montant_fcfa < MONTANT_PLANCHER_FCFA:
            return f"montant sous le plancher de {montant_lisible(MONTANT_PLANCHER_FCFA)}"
        if self.dernier_palier >= PALIER_MAXIMUM:
            return "trois relances deja envoyees, dossier a escalader"
        return None

    def palier_suivant(self) -> int:
        return min(self.dernier_palier + 1, PALIER_MAXIMUM)


@dataclass(frozen=True)
class Brouillon:
    """Un brouillon n'est pas un envoi : il attend une validation humaine."""
    brouillon_id: str
    facture_id: str
    palier: int
    objet: str
    corps: str
    cree_le: date

    def resume(self) -> str:
        return f"{self.brouillon_id} - {self.facture_id} - palier {self.palier}"


def montant_lisible(montant: int) -> str:
    """Un montant comme on l'ecrit sur une facture : groupes de mille espaces."""
    return f"{int(montant):,}".replace(",", "\u00a0") + "\u00a0F CFA"


def exposition(factures: list[Facture]) -> int:
    """La somme des montants : calculee ici, jamais par le modele de langage."""
    return sum(f.montant_fcfa for f in factures)
