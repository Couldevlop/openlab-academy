"""La boucle d'orchestration, ecrite a la main. Aucun cadre, cinq gardes."""
import json
from dataclasses import dataclass, field

from recouvrement.outils import REGISTRE, executer_outil
from recouvrement.trace import Trace

TOURS_MAXIMUM = 8
OBSERVATIONS_MAXIMUM = 12
BUDGET_FCFA_PAR_EXECUTION = 500


@dataclass
class EtatBoucle:
    """Tout ce que la boucle sait d'elle-meme, a un instant donne."""
    tour: int = 0
    depense_fcfa: int = 0
    observations: list[dict] = field(default_factory=list)
    appels_identiques: dict[str, int] = field(default_factory=dict)
    conclusion: str | None = None

    def resumer(self) -> str:
        """Ce que le modele relit a chaque tour : borne, donc previsible en cout."""
        recentes = self.observations[-OBSERVATIONS_MAXIMUM:]
        return "\n".join(
            f"- {o['outil']} -> {json.dumps(o['resultat'], ensure_ascii=False)[:300]}"
            for o in recentes)


class BoucleArretee(RuntimeError):
    """Arret volontaire : le message dit laquelle des cinq gardes a parle."""


def _verifier_les_gardes(etat: EtatBoucle, decision: dict) -> None:
    # Garde 1 : le nombre de tours. Sans elle, une boucle peut ne jamais finir.
    if etat.tour >= TOURS_MAXIMUM:
        raise BoucleArretee(f"plafond de {TOURS_MAXIMUM} tours atteint")
    # Garde 2 : le budget. Une boucle qui s'emballe coute de l'argent reel.
    if etat.depense_fcfa >= BUDGET_FCFA_PAR_EXECUTION:
        raise BoucleArretee(f"budget de {BUDGET_FCFA_PAR_EXECUTION} F CFA atteint")
    # Garde 3 : la repetition. Trois fois le meme appel identique = blocage.
    empreinte = json.dumps(decision, sort_keys=True, ensure_ascii=False)
    etat.appels_identiques[empreinte] = etat.appels_identiques.get(empreinte, 0) + 1
    if etat.appels_identiques[empreinte] >= 3:
        raise BoucleArretee("meme appel repete trois fois : le modele est bloque")


def executer_analyse(consigne: str, modele, age_min_jours: int = 30,
                     trace: Trace | None = None) -> dict:
    """Le chef d'orchestre. Le modele entre en parametre : un simule suffit aux tests."""
    trace = trace or Trace()
    etat = EtatBoucle()
    execution_id = trace.nouvelle_execution()
    outils_decrits = [{"nom": n, "description": (f.__doc__ or "").strip()}
                      for n, f in REGISTRE.items()]

    while etat.conclusion is None:
        try:
            reponse = modele.decider(consigne=consigne,
                                     observations=etat.resumer(),
                                     outils=outils_decrits)
        except Exception as erreur:                   # noqa: BLE001
            # Garde 4 : le modele indisponible arrete proprement, sans perdre l'etat.
            trace.ecrire(execution_id, "modele_indisponible", type=type(erreur).__name__)
            raise BoucleArretee("le modele ne repond pas") from erreur

        etat.depense_fcfa += reponse.cout_fcfa

        if reponse.conclusion is not None:
            etat.conclusion = reponse.conclusion
            break

        try:
            _verifier_les_gardes(etat, reponse.appel_outil)
        except BoucleArretee as arret:
            trace.ecrire(execution_id, "boucle_arretee", motif=str(arret))
            etat.conclusion = f"arret : {arret}"
            break

        # Une decision invalide n'est pas une exception : c'est une observation.
        resultat = executer_outil(reponse.appel_outil["nom"],
                                  reponse.appel_outil.get("arguments", {}),
                                  trace=trace)
        etat.observations.append({"outil": reponse.appel_outil["nom"],
                                  "resultat": resultat})
        etat.tour += 1

    # Garde 5 : le resultat est recalcule par le code, jamais repris du modele.
    retenues = _factures_retenues(etat)
    total = executer_outil("calculer_exposition", {"facture_ids": retenues}) \
        if retenues else {"ok": True, "donnees": {"total_fcfa": 0}}
    return {"execution_id": execution_id, "tours": etat.tour,
            "depense_fcfa": etat.depense_fcfa,
            "factures_retenues": retenues,
            "total_fcfa": total["donnees"]["total_fcfa"],
            "brouillons": _brouillons(etat),
            "conclusion": etat.conclusion}


def _factures_retenues(etat: EtatBoucle) -> list[str]:
    """Lu dans les observations reelles, pas dans le texte du modele."""
    for observation in reversed(etat.observations):
        if observation["outil"] == "lister_factures_impayees" and observation["resultat"]["ok"]:
            return [f["facture_id"]
                    for f in observation["resultat"]["donnees"]["factures"]]
    return []


def _brouillons(etat: EtatBoucle) -> list[str]:
    return [o["resultat"]["donnees"]["brouillon_id"]
            for o in etat.observations
            if o["outil"] == "preparer_brouillon_relance" and o["resultat"]["ok"]]
