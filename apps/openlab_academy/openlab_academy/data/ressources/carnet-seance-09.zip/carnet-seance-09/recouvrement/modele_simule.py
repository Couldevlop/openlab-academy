"""Un modele joue d'avance : des tests rapides, gratuits et deterministes."""
from dataclasses import dataclass


@dataclass
class Reponse:
    appel_outil: dict | None = None
    conclusion: str | None = None
    cout_fcfa: int = 1


class ModeleSimule:
    """Rejoue une liste de decisions. Sait aussi mal se comporter, c'est l'interet."""

    def __init__(self, decisions: list[Reponse]) -> None:
        self.decisions = list(decisions)
        self.appels = 0

    def decider(self, consigne: str, observations: str, outils: list[dict]) -> Reponse:
        self.appels += 1
        if not self.decisions:
            return Reponse(conclusion="plus rien a faire")
        return self.decisions.pop(0)


class ModeleEnPanne:
    """Pour verifier que la boucle s'arrete proprement sans perdre l'etat."""

    def decider(self, **_) -> Reponse:
        raise ConnectionError("le fournisseur ne repond pas")


class ModeleBloque:
    """Repete eternellement le meme appel : verifie la garde anti-repetition."""

    def decider(self, **_) -> Reponse:
        return Reponse(appel_outil={"nom": "lister_factures_impayees",
                                    "arguments": {"age_min_jours": 30}})
