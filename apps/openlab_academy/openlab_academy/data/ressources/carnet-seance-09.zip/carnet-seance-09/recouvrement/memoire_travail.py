"""Borne l'historique envoye au modele : les derniers tours en entier, le reste resume."""
from typing import Any

TOURS_INTACTS = 6        # messages recents gardes tels quels


def borner(historique: list[dict[str, Any]], resume: str | None) -> list[dict[str, Any]]:
    systeme = [m for m in historique[:1] if m.get("role") == "system"]
    corps = historique[len(systeme):]
    if len(corps) <= TOURS_INTACTS:
        return historique                       # rien a resumer, on ne touche a rien
    recents = corps[-TOURS_INTACTS:]
    ligne = {"role": "system",
             "content": f"Resume des echanges precedents : {resume or 'aucun'}"}
    return [*systeme, ligne, *recents]


def doit_resumer(historique: list[dict[str, Any]], dernier_resume_a: int) -> bool:
    """On resume tous les six tours, jamais a chaque tour : un resume coute un appel."""
    return len(historique) - dernier_resume_a >= TOURS_INTACTS * 2
