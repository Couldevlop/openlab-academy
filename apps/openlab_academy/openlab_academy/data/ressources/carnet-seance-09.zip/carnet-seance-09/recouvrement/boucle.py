"""La boucle : decider, agir, observer, s'arreter. Elle ignore quel modele l'anime."""
import json
import time
from dataclasses import dataclass
from typing import Any

from recouvrement.modele import (AppelOutil, Conclusion, Modele, ModeleIndisponible)
from recouvrement.outils import REGISTRE, executer_outil
from recouvrement.outils_schema import pour_le_modele
from recouvrement.trace import Trace


@dataclass
class Resultat:
    statut: str              # "termine", "plafond", "budget", "panne"
    texte: str
    tours: int
    jetons: int


def executer(modele: Modele, demande: str, systeme: str, reglages, trace: Trace) -> Resultat:
    historique: list[dict[str, Any]] = [
        {"role": "system", "content": systeme},
        {"role": "user", "content": demande},
    ]
    outils = pour_le_modele(REGISTRE)
    jetons = 0

    for tour in range(1, reglages.tours_max + 1):
        if jetons >= reglages.budget_jetons:               # garde 1 : avant l'appel
            trace.ecrire(tour=tour, evenement="budget_atteint", jetons=jetons)
            return Resultat("budget", "Budget atteint avant la fin.", tour, jetons)

        debut = time.monotonic()
        try:
            reponse = modele.decider(historique, outils)   # garde 2 : la panne est nommee
        except ModeleIndisponible as erreur:
            trace.ecrire(tour=tour, evenement="modele_indisponible", motif=str(erreur))
            return Resultat("panne", "Modele indisponible, resultat partiel.", tour, jetons)

        jetons += reponse.usage.total
        duree = round((time.monotonic() - debut) * 1000)

        if isinstance(reponse.decision, Conclusion):
            trace.ecrire(tour=tour, evenement="conclusion", duree_ms=duree,
                         jetons=reponse.usage.total)
            return Resultat("termine", reponse.decision.texte, tour, jetons)

        appel: AppelOutil = reponse.decision
        resultat = executer_outil(appel.nom, appel.arguments)   # garde 3 : liste blanche
        trace.ecrire(tour=tour, evenement="appel_outil", outil=appel.nom,
                     arguments=appel.arguments, ok=resultat.get("ok"),
                     duree_ms=duree, jetons=reponse.usage.total)

        historique.append({"role": "assistant", "tool_calls": [{
            "id": f"appel-{tour}", "type": "function",
            "function": {"name": appel.nom,
                         "arguments": json.dumps(appel.arguments, ensure_ascii=False)}}]})
        historique.append({"role": "tool", "tool_call_id": f"appel-{tour}",
                           "content": json.dumps(resultat, ensure_ascii=False)})
        # garde 4 : une erreur d'outil est une observation, pas une exception

    trace.ecrire(tour=reglages.tours_max, evenement="plafond_atteint")  # garde 5
    return Resultat("plafond", "Plafond de tours atteint.", reglages.tours_max, jetons)
