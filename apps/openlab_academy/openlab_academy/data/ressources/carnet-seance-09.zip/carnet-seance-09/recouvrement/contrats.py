"""Les contrats d'arguments. Un seul endroit, deux usages : valider et decrire."""
from pydantic import BaseModel, Field


class ListerFacturesImpayees(BaseModel):
    """Liste les factures dont le retard atteint age_min_jours."""
    age_min_jours: int = Field(default=30, ge=0, le=365,
                               description="retard minimal en jours")
    exclure_litiges: bool = Field(default=True,
                                  description="ecarte les factures en litige")


class CalculerExposition(BaseModel):
    """Somme les montants des factures citees, en francs CFA."""
    facture_ids: list[str] = Field(min_length=1, max_length=20,
                                   description="identifiants au format FAC-000")


class PreparerBrouillonRelance(BaseModel):
    """Prepare un brouillon local. Aucun envoi."""
    facture_id: str = Field(pattern=r"^FAC-\d{3}$")
    palier: int = Field(default=1, ge=1, le=3,
                        description="1 rappel courtois, 2 ferme, 3 mise en demeure")


class SoumettrePourValidation(BaseModel):
    """Place un brouillon en file d'attente humaine."""
    brouillon_id: str = Field(pattern=r"^BRO-\d{3}$")
    commentaire: str = Field(default="", max_length=300)


class EnregistrerRelanceSimulee(BaseModel):
    """Ecrit localement une relance approuvee. Aucun envoi, jamais."""
    brouillon_id: str = Field(pattern=r"^BRO-\d{3}$")
    validation_id: str = Field(pattern=r"^VAL-\d{3}$",
                               description="produit par une personne, jamais par l'agent")
    cle_idempotence: str = Field(min_length=8, max_length=64)


class ChercherDansLesConnaissances(BaseModel):
    """Cherche un passage dans la politique de relance interne."""
    question: str = Field(min_length=3, max_length=300)
    nombre_passages: int = Field(default=3, ge=1, le=5)


CONTRATS = {
    "lister_factures_impayees": ListerFacturesImpayees,
    "calculer_exposition": CalculerExposition,
    "preparer_brouillon_relance": PreparerBrouillonRelance,
    "soumettre_pour_validation": SoumettrePourValidation,
    "enregistrer_relance_simulee": EnregistrerRelanceSimulee,
    "chercher_dans_les_connaissances": ChercherDansLesConnaissances,
}
