"""Chargement du jeu de donnees. Un chargeur honnete refuse plutot que de deviner."""
import csv
import pathlib

from recouvrement.domaine import Facture

CHEMIN_PAR_DEFAUT = pathlib.Path("data/factures_fictives.csv")


class DonneesInvalides(ValueError):
    """Le numero de ligne est dans le message : c'est tout l'interet."""


def _entier(valeur: str, champ: str, ligne: int) -> int:
    try:
        nombre = int(str(valeur).strip())
    except (TypeError, ValueError):
        raise DonneesInvalides(f"ligne {ligne} : {champ} n'est pas un entier") from None
    if nombre < 0:
        raise DonneesInvalides(f"ligne {ligne} : {champ} negatif ({nombre})")
    return nombre


def charger_factures(chemin: pathlib.Path | None = None) -> list[Facture]:
    chemin = chemin or CHEMIN_PAR_DEFAUT
    if not chemin.exists():
        raise DonneesInvalides(f"fichier introuvable : {chemin}")
    factures: list[Facture] = []
    # utf-8-sig : l'export d'un tableur place souvent une marque invisible en tete.
    with chemin.open(encoding="utf-8-sig", newline="") as fichier:
        for ligne, enregistrement in enumerate(csv.DictReader(fichier), start=2):
            palier = _entier(enregistrement["dernier_palier"], "dernier_palier", ligne)
            if palier > 3:
                raise DonneesInvalides(f"ligne {ligne} : palier {palier} hors bornes")
            factures.append(Facture(
                facture_id=enregistrement["facture_id"].strip(),
                client_ref=enregistrement["client_ref"].strip(),
                montant_fcfa=_entier(enregistrement["montant_fcfa"], "montant", ligne),
                retard_jours=_entier(enregistrement["retard_jours"], "retard", ligne),
                en_litige=enregistrement["statut_litige"].strip() != "none",
                dernier_palier=palier,
                note_non_fiable=enregistrement.get("note_non_fiable", "").strip(),
            ))
    if not factures:
        raise DonneesInvalides("aucune facture chargee : fichier vide ?")
    return factures
