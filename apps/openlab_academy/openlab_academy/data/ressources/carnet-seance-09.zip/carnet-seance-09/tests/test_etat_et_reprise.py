"""On ne croit pas une reprise : on coupe le courant et on regarde."""
import json

from recouvrement.etat import CHEMIN, charger_etat, enregistrer_etat
from recouvrement.reprise import (cle_idempotence, demarrer_execution,
                                  etapes_deja_faites, marquer_etape)


def test_un_fichier_absent_est_un_premier_demarrage_pas_une_erreur(tmp_path, monkeypatch):
    monkeypatch.setattr("recouvrement.etat.CHEMIN", tmp_path / "etat.json")
    assert charger_etat()["brouillons"] == {}


def test_un_fichier_corrompu_est_mis_de_cote_et_pas_ecrase(tmp_path, monkeypatch):
    chemin = tmp_path / "etat.json"
    chemin.write_text("{ceci n'est pas du json", encoding="utf-8")
    monkeypatch.setattr("recouvrement.etat.CHEMIN", chemin)
    assert charger_etat()["version"] == 2
    assert chemin.with_suffix(".corrompu").exists()


def test_la_cle_d_idempotence_ne_depend_ni_de_l_heure_ni_du_hasard():
    premiere = cle_idempotence("BRO-001", "FAC-001", 1)
    seconde = cle_idempotence("BRO-001", "FAC-001", 1)
    assert premiere == seconde
    assert premiere != cle_idempotence("BRO-001", "FAC-001", 2)


def test_apres_coupure_les_etapes_faites_ne_sont_pas_refaites(tmp_path, monkeypatch):
    monkeypatch.setattr("recouvrement.etat.CHEMIN", tmp_path / "etat.json")
    demarrer_execution("exe-001", "analyse les impayes")
    marquer_etape("exe-001", "lister")
    marquer_etape("exe-001", "brouillon:FAC-001")
    # Ici, la machine redemarre : on relit tout depuis le disque.
    faites = etapes_deja_faites("exe-001")
    assert "brouillon:FAC-001" in faites
    assert "brouillon:FAC-004" not in faites


def test_l_ecriture_laisse_toujours_un_fichier_lisible(tmp_path, monkeypatch):
    chemin = tmp_path / "etat.json"
    monkeypatch.setattr("recouvrement.etat.CHEMIN", chemin)
    for tour in range(20):
        etat = charger_etat()
        etat["brouillons"][f"BRO-{tour:03d}"] = {"statut": "prepare"}
        enregistrer_etat(etat)
        json.loads(chemin.read_text(encoding="utf-8"))   # jamais a moitie ecrit
