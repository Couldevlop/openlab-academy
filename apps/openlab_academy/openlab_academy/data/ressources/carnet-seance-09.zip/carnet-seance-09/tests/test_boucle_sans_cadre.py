"""Une garde non testee est une garde qui sautera a la prochaine refonte."""
import pytest

from recouvrement.executer_boucle import BoucleArretee, executer_analyse
from recouvrement.modele_simule import (ModeleBloque, ModeleEnPanne,
                                        ModeleSimule, Reponse)


def test_la_boucle_s_arrete_quand_le_modele_conclut():
    modele = ModeleSimule([
        Reponse(appel_outil={"nom": "lister_factures_impayees",
                             "arguments": {"age_min_jours": 30}}),
        Reponse(conclusion="cinq factures relancables"),
    ])
    resultat = executer_analyse("analyse les impayes", modele)
    assert resultat["tours"] == 1
    assert resultat["conclusion"] == "cinq factures relancables"


def test_le_meme_appel_repete_trois_fois_arrete_la_boucle():
    resultat = executer_analyse("analyse", ModeleBloque())
    assert "repete trois fois" in resultat["conclusion"]


def test_un_outil_inconnu_devient_une_observation_pas_un_plantage():
    modele = ModeleSimule([
        Reponse(appel_outil={"nom": "outil_imaginaire", "arguments": {}}),
        Reponse(conclusion="j'ai corrige"),
    ])
    resultat = executer_analyse("analyse", modele)
    assert resultat["conclusion"] == "j'ai corrige"


def test_le_modele_en_panne_arrete_proprement():
    with pytest.raises(BoucleArretee, match="ne repond pas"):
        executer_analyse("analyse", ModeleEnPanne())


def test_le_total_est_recalcule_et_jamais_repris_du_modele():
    modele = ModeleSimule([
        Reponse(appel_outil={"nom": "lister_factures_impayees",
                             "arguments": {"age_min_jours": 30}}),
        Reponse(conclusion="le total est de 1 franc"),   # le modele se trompe
    ])
    resultat = executer_analyse("analyse", modele)
    assert resultat["total_fcfa"] > 1          # le code a recalcule
