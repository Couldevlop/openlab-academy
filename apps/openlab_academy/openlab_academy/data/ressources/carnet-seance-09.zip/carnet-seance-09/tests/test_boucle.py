"""La boucle se teste sans reseau : le modele est remplace par une liste de decisions."""
import pathlib

from recouvrement.boucle import executer
from recouvrement.config import Reglages
from recouvrement.modele import AppelOutil, Conclusion, ModeleIndisponible, Reponse, Usage
from recouvrement.trace import Trace


class ModeleJoue:
    """Joue les decisions prevues, dans l'ordre ; leve si on lui en demande une de trop."""

    def __init__(self, decisions):
        self.decisions = list(decisions)
        self.appels = 0

    def decider(self, historique, outils):
        self.appels += 1
        if not self.decisions:
            raise AssertionError("la boucle a demande une decision de trop")
        decision = self.decisions.pop(0)
        if isinstance(decision, Exception):
            raise decision
        return Reponse(decision, Usage(jetons_entree=100, jetons_sortie=20))


REGLAGES = Reglages(modele="test", cle="x", adresse=None, tours_max=3,
                    jetons_max=200, budget_jetons=10_000)


def _trace(tmp_path):
    return Trace(pathlib.Path(tmp_path) / "trace.jsonl")


def test_un_appel_puis_une_conclusion(tmp_path):
    modele = ModeleJoue([AppelOutil("lister_factures_impayees", {"age_min_jours": 30}),
                         Conclusion("cinq factures eligibles")])
    resultat = executer(modele, "prepare les relances", "systeme", REGLAGES, _trace(tmp_path))
    assert resultat.statut == "termine"
    assert resultat.tours == 2

def test_le_plafond_de_tours_arrete_la_boucle(tmp_path):
    bouclant = [AppelOutil("lister_factures_impayees", {"age_min_jours": 30})] * 5
    resultat = executer(ModeleJoue(bouclant), "x", "s", REGLAGES, _trace(tmp_path))
    assert resultat.statut == "plafond"
    assert resultat.tours == REGLAGES.tours_max

def test_une_panne_de_modele_arrete_proprement(tmp_path):
    modele = ModeleJoue([ModeleIndisponible("reseau coupe")])
    resultat = executer(modele, "x", "s", REGLAGES, _trace(tmp_path))
    assert resultat.statut == "panne"

def test_le_budget_coupe_avant_le_plafond(tmp_path):
    serre = Reglages(modele="t", cle="x", adresse=None, tours_max=10,
                     jetons_max=200, budget_jetons=1_000)
    decisions = [AppelOutil("lister_factures_impayees", {"age_min_jours": 30})] * 10
    resultat = executer(ModeleJoue(decisions), "x", "s", serre, _trace(tmp_path))
    assert resultat.statut == "budget"
