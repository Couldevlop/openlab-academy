"""Ces quatre tests resteront verts pendant douze seances. Ecrivez-les maintenant."""
from recouvrement.outils import executer_outil


def test_un_outil_hors_liste_blanche_est_refuse_et_journalise(capsys):
    resultat = executer_outil("supprimer_la_base", {})
    assert resultat["ok"] is False
    assert "inconnu" in resultat["erreur"]
    assert "outil_refuse" in capsys.readouterr().out


def test_un_argument_hors_bornes_n_atteint_jamais_le_code_metier():
    resultat = executer_outil("lister_factures_impayees", {"age_min_jours": -5})
    assert resultat["ok"] is False
    assert "arguments invalides" in resultat["erreur"]


def test_une_facture_en_litige_ne_produit_aucun_brouillon():
    resultat = executer_outil("preparer_brouillon_relance", {"facture_id": "FAC-003"})
    assert resultat["ok"] is False
    assert "litige" in resultat["erreur"]


def test_la_forme_de_reponse_est_toujours_la_meme():
    for appel in [("lister_factures_impayees", {}), ("outil_imaginaire", {})]:
        resultat = executer_outil(*appel)
        assert set(resultat) <= {"ok", "donnees", "erreur", "outils_disponibles"}
        assert isinstance(resultat["ok"], bool)
