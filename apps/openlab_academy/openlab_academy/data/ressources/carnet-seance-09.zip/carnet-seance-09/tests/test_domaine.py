"""Ecrits avant la boucle : ils tiendront pendant les seize seances."""
from recouvrement.domaine import Facture, exposition


def facture(**remplacements) -> Facture:
    """Une facture relancable par defaut ; on ne modifie que ce qu'on teste."""
    valeurs = dict(facture_id="FAC-001", client_ref="CLI-001",
                   montant_fcfa=1_250_000, retard_jours=45,
                   en_litige=False, dernier_palier=0)
    valeurs.update(remplacements)
    return Facture(**valeurs)


def test_une_facture_en_retard_et_hors_litige_est_relancable():
    assert facture().est_relancable()


def test_un_litige_bloque_la_relance_quel_que_soit_le_montant():
    bloquee = facture(en_litige=True, montant_fcfa=50_000_000)
    assert not bloquee.est_relancable()
    assert bloquee.motif_exclusion() == "litige en cours"


def test_sous_le_seuil_de_retard_rien_ne_part():
    assert not facture(retard_jours=29).est_relancable()


def test_sous_le_plancher_de_montant_la_relance_ne_vaut_pas_son_cout():
    assert not facture(montant_fcfa=499_999).est_relancable()


def test_apres_trois_relances_le_dossier_s_escalade():
    assert not facture(dernier_palier=3).est_relancable()


def test_l_exposition_est_calculee_par_le_code_jamais_par_le_modele():
    total = exposition([facture(montant_fcfa=1_000_000),
                        facture(montant_fcfa=250_000)])
    assert total == 1_250_000
