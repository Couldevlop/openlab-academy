"""La recherche se mesure : rappel et rang moyen sur un jeu de questions annotees."""
from recouvrement.corpus import decouper
from recouvrement.index_lexical import IndexLexical
from recouvrement.recherche import RechercheHybride

JEU = [
    ("a partir de combien de jours peut-on relancer", "politique_relance#seuil-d-eligibilite"),
    ("puis-je relancer un client qui conteste sa facture", "politique_relance#factures-en-litige"),
    ("quand peut-on passer au palier 2", "politique_relance#paliers"),
    ("a partir de quel montant previent-on le responsable",
     "politique_relance#montants-et-devise"),
]


def _recherche() -> RechercheHybride:
    return RechercheHybride(IndexLexical(decouper()))


def test_le_bon_passage_est_dans_les_trois_premiers():
    recherche, manques = _recherche(), []
    for question, attendu in JEU:
        trouves = [p.identifiant for p, _ in recherche.chercher(question, k=3)]
        if attendu not in trouves:
            manques.append((question, attendu, trouves))
    assert not manques, manques        # le message nomme la question qui echoue


def test_le_rang_moyen_reste_bon():
    recherche, rangs = _recherche(), []
    for question, attendu in JEU:
        trouves = [p.identifiant for p, _ in recherche.chercher(question, k=5)]
        rangs.append(trouves.index(attendu) + 1 if attendu in trouves else 6)
    assert sum(rangs) / len(rangs) <= 2.0, rangs
