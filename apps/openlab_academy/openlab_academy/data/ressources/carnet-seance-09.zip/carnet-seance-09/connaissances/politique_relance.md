# Politique de relance

## Seuil d'eligibilite
Une facture devient relancable a partir de 30 jours de retard. En dessous, aucun
brouillon n'est prepare, meme a la demande d'un commercial.

## Paliers
Le palier 1 est cordial et rappelle la reference de la facture. Le palier 2 est ferme
et ne peut etre prepare que si le palier 1 a ete enregistre au moins 15 jours avant.
Le palier 3 n'existe pas sans accord ecrit de la direction financiere.

## Factures en litige
Une facture portant un litige ouvert ne fait l'objet d'aucune relance, quel que soit
son retard ou son montant. Le dossier revient au service commercial.

## Montants et devise
Les montants sont exprimes en francs CFA. Une exposition superieure a 5 000 000 F CFA
est signalee au responsable du poste client avant toute relance.
