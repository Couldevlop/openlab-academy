"""Additionne les jetons d'une trace et convertit en francs CFA."""
import json
import pathlib
import sys

# tarifs lus chez le fournisseur, en F CFA par million de jetons ; a dater et a verifier
TARIFS = {"gpt-4o-mini": {"entree": 98_000, "sortie": 393_000}}


def mesurer(trace: pathlib.Path, modele: str) -> dict:
    entree = sortie = tours = 0
    for ligne in trace.read_text(encoding="utf-8").splitlines():
        evenement = json.loads(ligne)
        entree += evenement.get("jetons_entree", 0)
        sortie += evenement.get("jetons_sortie", evenement.get("jetons", 0))
        tours += 1
    tarif = TARIFS.get(modele)
    if tarif is None:
        raise SystemExit(f"tarif inconnu pour {modele} : ajoutez-le et datez-le")
    cout = (entree * tarif["entree"] + sortie * tarif["sortie"]) / 1_000_000
    return {"tours": tours, "jetons_entree": entree, "jetons_sortie": sortie,
            "cout_fcfa": round(cout)}


if __name__ == "__main__":
    print(json.dumps(mesurer(pathlib.Path(sys.argv[1]), sys.argv[2]), indent=2))
