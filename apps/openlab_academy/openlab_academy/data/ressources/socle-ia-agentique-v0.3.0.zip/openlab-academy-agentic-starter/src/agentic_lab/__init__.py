"""Laboratoire pédagogique OpenLab Academy."""
