# Dépôt du fil rouge — séance 12

CrewAI, PydanticAI et GenAI, puis le comparatif

Le code de l'agent de recouvrement, dans l'état où le cours le laisse à la fin de la séance 12 : ni plus, ni moins que ce que la séance vous a fait écrire.

## Pour l'ouvrir

```bash
python -m venv .venv && . .venv/bin/activate   # Windows : .venv\Scripts\activate
pip install pydantic pytest
python -m pytest
```

Lancez les commandes depuis cette racine : les chemins `data/`, `connaissances/` et `contracts/` en dépendent. Certaines séances ajoutent une dépendance (LangGraph, CrewAI, le client MCP) : le cours le dit au moment où elle sert.

Aucun appel à un service distant n'est nécessaire, et aucune clé : les données sont fictives.
