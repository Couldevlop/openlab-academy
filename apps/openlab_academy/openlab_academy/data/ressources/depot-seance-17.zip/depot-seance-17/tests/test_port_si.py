"""Deux niveaux : un faux pour tous les tests metier, quelques tests de contrat."""
import os
from datetime import date, timedelta

import pytest

from recouvrement.domaine import Facture
from recouvrement.port_si import (EtatDuSysteme, Paiement,
                                  factures_apres_rapprochement)


class SiEnMemoire:
    """Implemente le port sans aucun reseau : rapide, gratuit, deterministe."""

    def __init__(self, factures=None, paiements=None) -> None:
        self.factures = factures or []
        self.paiements = paiements or []
        self.notes: list[tuple] = []

    def factures_impayees(self, age_min_jours: int) -> list[Facture]:
        return [f for f in self.factures if f.retard_jours >= age_min_jours]

    def paiements_recents(self, depuis: date) -> list[Paiement]:
        return [p for p in self.paiements if p.recu_le >= depuis]

    def deposer_note_interne(self, client_ref, texte, validation_id) -> str:
        self.notes.append((client_ref, texte, validation_id))
        return f"NOTE-{len(self.notes):03d}"

    def sante(self) -> EtatDuSysteme:
        return EtatDuSysteme(joignable=True, version="memoire")


def facture(identifiant, retard=45):
    return Facture(facture_id=identifiant, client_ref="CLI-001",
                   montant_fcfa=1_250_000, retard_jours=retard,
                   en_litige=False, dernier_palier=0)


def test_une_facture_payee_entre_temps_n_est_plus_relancee():
    factures = [facture("FAC-001"), facture("FAC-004")]
    paiements = [Paiement("FAC-001", 1_250_000, date.today(), "VIR-1")]
    restantes = factures_apres_rapprochement(factures, paiements)
    assert [f.facture_id for f in restantes] == ["FAC-004"]


def test_la_note_porte_toujours_l_identifiant_de_validation():
    systeme = SiEnMemoire()
    systeme.deposer_note_interne("42", "Relance palier 1", "VAL-007")
    assert systeme.notes[0][2] == "VAL-007"


# --- tests de contrat : seulement si un bac a sable tourne ---------------------

@pytest.mark.skipif(not os.environ.get("ODOO_URL"),
                    reason="aucun bac a sable Odoo disponible")
def test_contrat_odoo_renvoie_bien_des_factures_du_domaine():
    from integrations.odoo import AdaptateurOdoo
    adaptateur = AdaptateurOdoo()
    assert adaptateur.sante().joignable
    for f in adaptateur.factures_impayees(30):
        assert isinstance(f, Facture)
        assert f.montant_fcfa > 0 and f.retard_jours >= 30


@pytest.mark.skipif(not os.environ.get("DOLIBARR_URL"),
                    reason="aucun bac a sable Dolibarr disponible")
def test_contrat_dolibarr_pagine_au_dela_d_une_page():
    from integrations.dolibarr import AdaptateurDolibarr
    factures = AdaptateurDolibarr().factures_impayees(0)
    assert len({f.facture_id for f in factures}) == len(factures)
