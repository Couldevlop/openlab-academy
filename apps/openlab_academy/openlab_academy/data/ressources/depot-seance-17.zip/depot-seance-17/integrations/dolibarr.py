"""Adaptateur Dolibarr. REST, cle d'API dans l'en-tete DOLAPIKEY."""
import os
from datetime import date, datetime, timedelta

import httpx

from recouvrement.domaine import Facture
from recouvrement.port_si import EtatDuSysteme, Paiement, SystemeIndisponible

PAGE = 100          # la pagination se gere, sinon on perd des lignes en silence


class AdaptateurDolibarr:
    def __init__(self, url: str | None = None, cle: str | None = None,
                 delai_s: float = 10.0) -> None:
        self.url = (url or os.environ["DOLIBARR_URL"]).rstrip("/")
        self.client = httpx.Client(
            timeout=delai_s,
            headers={"DOLAPIKEY": cle or os.environ["DOLIBARR_CLE"],
                     "Accept": "application/json"})

    def _lire_tout(self, ressource: str, parametres: dict) -> list[dict]:
        page, lignes = 0, []
        while True:
            requete = dict(parametres, limit=PAGE, page=page)
            try:
                reponse = self.client.get(f"{self.url}/api/index.php/{ressource}",
                                          params=requete)
            except httpx.HTTPError as erreur:
                raise SystemeIndisponible(f"Dolibarr injoignable : {erreur}") from erreur
            if reponse.status_code == 404:      # Dolibarr repond 404 sur page vide
                return lignes
            if reponse.status_code >= 400:
                raise SystemeIndisponible(f"Dolibarr : HTTP {reponse.status_code}")
            lot = reponse.json()
            lignes.extend(lot)
            if len(lot) < PAGE:
                return lignes
            page += 1

    def factures_impayees(self, age_min_jours: int) -> list[Facture]:
        limite = date.today() - timedelta(days=age_min_jours)
        filtre = {"sqlfilters": "(t.fk_statut:=:1) and (t.paye:=:0)"}
        factures = []
        for ligne in self._lire_tout("invoices", filtre):
            echeance = datetime.fromtimestamp(int(ligne["date_lim_reglement"])).date()
            if echeance > limite:
                continue
            factures.append(Facture(
                facture_id=ligne["ref"],
                client_ref=str(ligne["socid"]),
                montant_fcfa=int(round(float(ligne["total_ttc"]))),
                retard_jours=(date.today() - echeance).days,
                en_litige=False, dernier_palier=0))
        return factures

    def paiements_recents(self, depuis: date) -> list[Paiement]:
        paiements = []
        for ligne in self._lire_tout("invoices/payments", {}):
            recu = datetime.fromtimestamp(int(ligne["date"])).date()
            if recu >= depuis:
                paiements.append(Paiement(facture_id=ligne.get("ref_invoice", ""),
                                          montant_fcfa=int(round(float(ligne["amount"]))),
                                          recu_le=recu,
                                          reference=str(ligne["id"])))
        return paiements

    def deposer_note_interne(self, client_ref: str, texte: str,
                             validation_id: str) -> str:
        corps = {"socid": int(client_ref), "type_code": "AC_OTH",
                 "label": "Relance preparee par agent",
                 "note": f"{texte}\n\n[validation {validation_id}]"}
        reponse = self.client.post(f"{self.url}/api/index.php/agendaevents", json=corps)
        if reponse.status_code >= 400:
            raise SystemeIndisponible(f"depot refuse : HTTP {reponse.status_code}")
        return str(reponse.json())

    def sante(self) -> EtatDuSysteme:
        try:
            reponse = self.client.get(f"{self.url}/api/index.php/status")
            return EtatDuSysteme(joignable=reponse.status_code == 200,
                                 version=reponse.json().get("success", {})
                                 .get("dolibarr_version", ""))
        except Exception as erreur:                  # noqa: BLE001
            return EtatDuSysteme(joignable=False, detail=str(erreur))
