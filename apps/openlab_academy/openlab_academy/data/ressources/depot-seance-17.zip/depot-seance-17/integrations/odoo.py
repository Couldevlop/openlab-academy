"""Adaptateur Odoo (Community). Installation : pip install "httpx".

Compte technique en lecture seule, jamais un administrateur.
"""
import os
from datetime import date, timedelta

import httpx

from recouvrement.domaine import Facture
from recouvrement.port_si import EtatDuSysteme, Paiement, SystemeIndisponible


class AdaptateurOdoo:
    def __init__(self, url: str | None = None, base: str | None = None,
                 utilisateur: str | None = None, mot_de_passe: str | None = None,
                 delai_s: float = 10.0) -> None:
        self.url = (url or os.environ["ODOO_URL"]).rstrip("/")
        self.base = base or os.environ["ODOO_BASE"]
        self.utilisateur = utilisateur or os.environ["ODOO_UTILISATEUR"]
        self.mot_de_passe = mot_de_passe or os.environ["ODOO_MOT_DE_PASSE"]
        self.client = httpx.Client(timeout=delai_s)
        self._uid: int | None = None

    # --- plomberie JSON-RPC -------------------------------------------------
    def _appeler(self, service: str, methode: str, arguments: list):
        corps = {"jsonrpc": "2.0", "method": "call",
                 "params": {"service": service, "method": methode,
                            "args": arguments}}
        try:
            reponse = self.client.post(f"{self.url}/jsonrpc", json=corps)
            reponse.raise_for_status()
        except httpx.HTTPError as erreur:
            raise SystemeIndisponible(f"Odoo injoignable : {erreur}") from erreur
        charge = reponse.json()
        if "error" in charge:
            # On n'expose pas la trace Odoo au modele : seulement le message.
            message = charge["error"].get("data", {}).get("message", "erreur Odoo")
            raise SystemeIndisponible(message)
        return charge["result"]

    def _uid_connecte(self) -> int:
        if self._uid is None:
            self._uid = self._appeler("common", "login",
                                      [self.base, self.utilisateur, self.mot_de_passe])
            if not self._uid:
                raise SystemeIndisponible("authentification Odoo refusee")
        return self._uid

    def _lire(self, modele: str, conditions: list, champs: list[str],
              limite: int = 200) -> list[dict]:
        return self._appeler("object", "execute_kw", [
            self.base, self._uid_connecte(), self.mot_de_passe, modele,
            "search_read", [conditions], {"fields": champs, "limit": limite}])

    # --- le port ------------------------------------------------------------
    def factures_impayees(self, age_min_jours: int) -> list[Facture]:
        echeance = (date.today() - timedelta(days=age_min_jours)).isoformat()
        # Le filtrage se fait chez Odoo : ramener tout serait lent et inutile.
        conditions = [["move_type", "=", "out_invoice"],
                      ["state", "=", "posted"],
                      ["payment_state", "in", ["not_paid", "partial"]],
                      ["invoice_date_due", "<=", echeance]]
        champs = ["name", "partner_id", "amount_residual", "invoice_date_due"]
        factures = []
        for ligne in self._lire("account.move", conditions, champs):
            retard = (date.today()
                      - date.fromisoformat(ligne["invoice_date_due"])).days
            factures.append(Facture(
                facture_id=ligne["name"],
                client_ref=str(ligne["partner_id"][0]),
                # Arrondi au dernier moment : le domaine travaille en entiers.
                montant_fcfa=int(round(ligne["amount_residual"])),
                retard_jours=retard,
                en_litige=False,          # le litige vient de votre table, pas d'Odoo
                dernier_palier=0,
                note_non_fiable=""))      # jamais de champ libre Odoo dans le domaine
        return factures

    def paiements_recents(self, depuis: date) -> list[Paiement]:
        conditions = [["state", "=", "posted"], ["date", ">=", depuis.isoformat()]]
        champs = ["name", "amount", "date", "ref"]
        return [Paiement(facture_id=(l.get("ref") or "").strip(),
                         montant_fcfa=int(round(l["amount"])),
                         recu_le=date.fromisoformat(l["date"]),
                         reference=l["name"])
                for l in self._lire("account.payment", conditions, champs)]

    def deposer_note_interne(self, client_ref: str, texte: str,
                             validation_id: str) -> str:
        """La seule ecriture autorisee : un message sur la fiche client.

        Aucun effet comptable. Le validation_id est inscrit dans la note : la trace
        dit toujours quelle personne a autorise ce depot.
        """
        corps = f"{texte}\n\n[relance preparee par agent, validation {validation_id}]"
        identifiant = self._appeler("object", "execute_kw", [
            self.base, self._uid_connecte(), self.mot_de_passe,
            "mail.message", "create",
            [{"model": "res.partner", "res_id": int(client_ref),
              "body": corps, "message_type": "comment"}]])
        return str(identifiant)

    def sante(self) -> EtatDuSysteme:
        try:
            version = self._appeler("common", "version", [])
            return EtatDuSysteme(joignable=True,
                                 version=str(version.get("server_version", "")))
        except SystemeIndisponible as erreur:
            return EtatDuSysteme(joignable=False, detail=str(erreur))
