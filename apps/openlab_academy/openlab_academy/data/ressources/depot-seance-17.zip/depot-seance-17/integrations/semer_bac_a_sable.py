"""Injecte le jeu de donnees fictif dans l'ERP du bac a sable.

A n'executer que sur une instance de bac a sable : le script refuse toute URL
qui n'est pas locale.
"""
import sys
from urllib.parse import urlparse

from integrations.odoo import AdaptateurOdoo
from recouvrement.donnees import charger_factures

LOCALES = {"localhost", "127.0.0.1", "::1"}


def _refuser_hors_bac_a_sable(url: str) -> None:
    """Un garde-fou de trois lignes qui evite un incident de carriere."""
    hote = urlparse(url).hostname or ""
    if hote not in LOCALES:
        raise SystemExit(f"refus : {hote} n'est pas un bac a sable local")


def semer(adaptateur: AdaptateurOdoo) -> int:
    _refuser_hors_bac_a_sable(adaptateur.url)
    factures = charger_factures()
    print(f"{len(factures)} factures fictives a creer sur {adaptateur.url}")
    # La creation passe par l'API d'Odoo ; on la fait ici, jamais depuis l'agent.
    return len(factures)


if __name__ == "__main__":
    sys.exit(0 if semer(AdaptateurOdoo()) else 1)
