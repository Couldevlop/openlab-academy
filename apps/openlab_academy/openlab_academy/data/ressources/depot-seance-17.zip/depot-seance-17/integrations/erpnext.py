"""Adaptateur ERPNext. REST, authentification par couple de jetons."""
import json
import os
from datetime import date, timedelta

import httpx

from recouvrement.domaine import Facture
from recouvrement.port_si import EtatDuSysteme, Paiement, SystemeIndisponible


class AdaptateurErpNext:
    def __init__(self, url: str | None = None, cle: str | None = None,
                 secret: str | None = None, delai_s: float = 10.0) -> None:
        self.url = (url or os.environ["ERPNEXT_URL"]).rstrip("/")
        jeton = f"{cle or os.environ['ERPNEXT_CLE']}:" \
                f"{secret or os.environ['ERPNEXT_SECRET']}"
        self.client = httpx.Client(timeout=delai_s,
                                   headers={"Authorization": f"token {jeton}"})

    def _lire(self, doctype: str, filtres: list, champs: list[str],
              limite: int = 200) -> list[dict]:
        parametres = {"filters": json.dumps(filtres),
                      "fields": json.dumps(champs),
                      "limit_page_length": limite}
        try:
            reponse = self.client.get(f"{self.url}/api/resource/{doctype}",
                                      params=parametres)
        except httpx.HTTPError as erreur:
            raise SystemeIndisponible(f"ERPNext injoignable : {erreur}") from erreur
        if reponse.status_code >= 400:
            raise SystemeIndisponible(f"ERPNext : HTTP {reponse.status_code}")
        return reponse.json().get("data", [])

    def factures_impayees(self, age_min_jours: int) -> list[Facture]:
        echeance = (date.today() - timedelta(days=age_min_jours)).isoformat()
        filtres = [["status", "in", ["Unpaid", "Overdue", "Partly Paid"]],
                   ["due_date", "<=", echeance], ["docstatus", "=", 1]]
        champs = ["name", "customer", "outstanding_amount", "due_date"]
        return [Facture(facture_id=l["name"], client_ref=l["customer"],
                        montant_fcfa=int(round(float(l["outstanding_amount"]))),
                        retard_jours=(date.today()
                                      - date.fromisoformat(l["due_date"])).days,
                        en_litige=False, dernier_palier=0)
                for l in self._lire("Sales Invoice", filtres, champs)]

    def paiements_recents(self, depuis: date) -> list[Paiement]:
        filtres = [["posting_date", ">=", depuis.isoformat()], ["docstatus", "=", 1]]
        champs = ["name", "paid_amount", "posting_date", "reference_no"]
        return [Paiement(facture_id=l.get("reference_no") or "",
                         montant_fcfa=int(round(float(l["paid_amount"]))),
                         recu_le=date.fromisoformat(l["posting_date"]),
                         reference=l["name"])
                for l in self._lire("Payment Entry", filtres, champs)]

    def deposer_note_interne(self, client_ref: str, texte: str,
                             validation_id: str) -> str:
        corps = {"doctype": "Comment", "comment_type": "Comment",
                 "reference_doctype": "Customer", "reference_name": client_ref,
                 "content": f"{texte}\n\n[validation {validation_id}]"}
        reponse = self.client.post(f"{self.url}/api/resource/Comment", json=corps)
        if reponse.status_code >= 400:
            raise SystemeIndisponible(f"depot refuse : HTTP {reponse.status_code}")
        return reponse.json()["data"]["name"]

    def sante(self) -> EtatDuSysteme:
        try:
            reponse = self.client.get(f"{self.url}/api/method/ping")
            return EtatDuSysteme(joignable=reponse.status_code == 200,
                                 version="ERPNext")
        except Exception as erreur:                  # noqa: BLE001
            return EtatDuSysteme(joignable=False, detail=str(erreur))
