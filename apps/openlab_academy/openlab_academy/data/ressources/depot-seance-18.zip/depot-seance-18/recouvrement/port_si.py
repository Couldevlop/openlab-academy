"""Le port : ce dont le domaine a besoin, dans son vocabulaire a lui."""
from dataclasses import dataclass
from datetime import date
from typing import Protocol

from recouvrement.domaine import Facture


@dataclass(frozen=True)
class Paiement:
    """Un reglement rattache a une facture, lu dans le systeme source."""
    facture_id: str
    montant_fcfa: int
    recu_le: date
    reference: str


@dataclass(frozen=True)
class EtatDuSysteme:
    """Ce que la sonde de la seance 16 a besoin de savoir."""
    joignable: bool
    version: str = ""
    detail: str = ""


class SystemeIndisponible(RuntimeError):
    """Le systeme source ne repond pas. Ce n'est pas une panne de votre agent."""


class PorteSI(Protocol):
    """Un ERP incapable de fournir ces quatre methodes est disqualifie."""

    def factures_impayees(self, age_min_jours: int) -> list[Facture]: ...

    def paiements_recents(self, depuis: date) -> list[Paiement]: ...

    def deposer_note_interne(self, client_ref: str, texte: str,
                             validation_id: str) -> str: ...

    def sante(self) -> EtatDuSysteme: ...


def factures_apres_rapprochement(factures: list[Facture],
                                 paiements: list[Paiement]) -> list[Facture]:
    """Une facture payee entre-temps ne se relance pas. Regle du domaine, pas de l'ERP."""
    regles = {p.facture_id for p in paiements}
    return [f for f in factures if f.facture_id not in regles]
