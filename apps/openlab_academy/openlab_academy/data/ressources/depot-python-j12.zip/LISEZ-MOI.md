# Dépôt de la journée 12

Trois commandes, dans ce dossier.

1. Installer l'outil de test, une seule fois :
   - Windows : `py -m pip install pytest`
   - macOS et Linux : `python3 -m pip install pytest`
2. Lancer les tests : `python -m pytest`
3. Lancer votre programme : `python rh/calculs.py`

Les tests échouent au départ : c'est voulu. Votre challenge consiste à les faire passer.

Le dossier `corrige/` contient la solution de la journée précédente. Comparez-la à la vôtre
seulement après avoir rendu votre propre version.

Données entièrement fictives : aucun fichier de paie réel ne doit entrer dans ce dossier.
