"""Charge le dossier connaissances avec les composants du cadre, puis rend des documents citables."""
import pathlib

from langchain_community.document_loaders import TextLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

DOSSIER = pathlib.Path("connaissances")
TAILLE = 700          # caracteres : un passage se lit, et se paie
CHEVAUCHEMENT = 120   # une phrase coupee en deux reste trouvable

def charger(dossier: pathlib.Path = DOSSIER) -> list[Document]:
    documents: list[Document] = []
    for fichier in sorted(dossier.glob("*.md")):
        # autodetect_encoding reste a False : on impose utf-8 plutot que de deviner
        documents.extend(TextLoader(str(fichier), encoding="utf-8").load())
    if not documents:
        raise RuntimeError(f"aucun document dans {dossier}")
    return documents

def decouper(documents: list[Document]) -> list[Document]:
    decoupeur = RecursiveCharacterTextSplitter(
        chunk_size=TAILLE, chunk_overlap=CHEVAUCHEMENT,
        separators=["\n## ", "\n\n", "\n", ". ", " "])
    passages = decoupeur.split_documents(documents)
    for rang, passage in enumerate(passages, start=1):
        document = pathlib.Path(passage.metadata.get("source", "inconnu")).stem
        # le cadre ne fabrique pas d'identifiant citable : nous le faisons, sinon
        # la reponse du modele ne peut pas etre verifiee par un humain
        passage.metadata["document"] = document
        passage.metadata["identifiant"] = f"{document}#p{rang:02d}"
    return passages

def citable(passage: Document) -> str:
    return f"{passage.metadata['identifiant']} ({passage.metadata['document']})"
