"""Les trois recuperateurs du cadre : lexical, vectoriel optionnel, et leur fusion."""
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever

from cadres.chargement_langchain import charger, decouper

POIDS_LEXICAL = 0.5     # a regler apres mesure, jamais avant
POIDS_VECTORIEL = 0.5

def passages() -> list[Document]:
    return decouper(charger())

def recuperateur_lexical(documents: list[Document], k: int = 3) -> BaseRetriever:
    """BM25, la formule de la seance 9, en une ligne."""
    recuperateur = BM25Retriever.from_documents(documents)
    recuperateur.k = k
    return recuperateur

def recuperateur_vectoriel(documents: list[Document], k: int = 3) -> BaseRetriever | None:
    """Rend None si la dependance manque : le repli est annonce, jamais silencieux."""
    try:
        from langchain_community.vectorstores import FAISS
        from langchain_huggingface import HuggingFaceEmbeddings
    except ImportError:
        return None
    plongement = HuggingFaceEmbeddings(model_name="intfloat/multilingual-e5-small")
    return FAISS.from_documents(documents, plongement).as_retriever(
        search_kwargs={"k": k})

def recuperateur(documents: list[Document] | None = None, k: int = 3) -> BaseRetriever:
    documents = documents if documents is not None else passages()
    lexical = recuperateur_lexical(documents, k)
    vectoriel = recuperateur_vectoriel(documents, k)
    if vectoriel is None:
        print("recherche vectorielle absente : recherche lexicale seule")
        return lexical
    # la fusion par rang reciproque de la seance 9, avec des poids en plus
    return EnsembleRetriever(retrievers=[lexical, vectoriel],
                             weights=[POIDS_LEXICAL, POIDS_VECTORIEL])
