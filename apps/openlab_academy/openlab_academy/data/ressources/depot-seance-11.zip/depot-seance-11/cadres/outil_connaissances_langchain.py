"""Le sixieme outil, servi par la chaine du cadre : meme contrat, meme forme de reponse."""
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from cadres.chargement_langchain import citable
from cadres.recherche_langchain import recuperateur

EXTRAIT_MAX = 500      # un passage long est tronque : le contexte se paie

class ArgumentsRecherche(BaseModel):
    # les memes noms que le contrat JSON de la seance 9 : un seul vocabulaire
    question: str = Field(min_length=3, max_length=300)
    nombre_passages: int = Field(default=3, ge=1, le=5)

def chercher_procedure(chercheur=None, **bruts: Any) -> dict:
    try:
        args = ArgumentsRecherche(**bruts)
    except ValidationError as erreur:
        return {"ok": False, "erreur": "Arguments invalides",
                "details": erreur.errors(include_url=False)}
    chercheur = chercheur or recuperateur(k=args.nombre_passages)
    trouves = chercheur.invoke(args.question)[:args.nombre_passages]
    if not trouves:
        return {"ok": True, "donnees": {"passages": []},
                "message": "aucune procedure ne repond"}
    return {"ok": True, "donnees": {"passages": [
        {"identifiant": passage.metadata["identifiant"],
         "source": citable(passage),
         "extrait": passage.page_content[:EXTRAIT_MAX]}
        for passage in trouves]}}
