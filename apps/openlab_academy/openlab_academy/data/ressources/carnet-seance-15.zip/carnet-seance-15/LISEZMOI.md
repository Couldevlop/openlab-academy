# Carnet d'exercices — séance 15

Sécurité, évaluation et observabilité

## Pour démarrer

```bash
python -m venv .venv && . .venv/bin/activate   # Windows : .venv\\Scripts\\activate
pip install jupyterlab pydantic pytest
jupyter lab seance-15.ipynb
```

Le dépôt du fil rouge est livré à côté du carnet, dans l'état où le cours le laisse à la fin de la séance 15. Ouvrez le carnet depuis cette racine : les chemins `data/`, `connaissances/` et `contracts/` en dépendent.

## Ce qu'il contient

- `seance-15.ipynb` : le carnet, à exécuter dans l'ordre ;
- `recouvrement/`, `tests/` : le code du fil rouge, identique à celui du cours ;
- `data/`, `connaissances/`, `contracts/` : les données du fil rouge, fictives.

Aucune cellule n'appelle de service distant et aucune clé n'est nécessaire.
Rien n'est envoyé : la seule écriture possible est une relance simulée, locale.
