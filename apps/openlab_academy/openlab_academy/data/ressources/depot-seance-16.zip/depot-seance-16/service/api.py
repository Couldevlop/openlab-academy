"""Porte d'entree HTTP de l'agent. Installation : pip install "fastapi" "uvicorn"."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from recouvrement.configuration import charger_configuration
from recouvrement.etat import charger_etat, enregistrer_etat
from recouvrement.executer_boucle import executer_analyse
from recouvrement.trace import Trace

application = FastAPI(title="Agent de recouvrement", version="1.0.0")


class DemandeAnalyse(BaseModel):
    age_min_jours: int = Field(default=30, ge=0, le=365)


class DemandeApprobation(BaseModel):
    brouillon_id: str = Field(pattern=r"^BRO-\d{3}$")
    approuve: bool
    valideur: str = Field(min_length=2, max_length=60)


@application.get("/sante")
def sante() -> dict:
    """Vivant ne suffit pas : on verifie aussi la configuration et l'etat."""
    try:
        configuration = charger_configuration()
        etat = charger_etat()
    except Exception as erreur:                       # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"indisponible : {erreur}")
    return {"ok": True, "modele": configuration.modele,
            "executions": len(etat.get("executions", []))}


@application.post("/analyses")
def lancer_analyse(demande: DemandeAnalyse) -> dict:
    trace = Trace()
    resultat = executer_analyse(age_min_jours=demande.age_min_jours, trace=trace)
    return {"execution_id": resultat["execution_id"],
            "factures_retenues": resultat["factures_retenues"],
            "total_fcfa": resultat["total_fcfa"],
            "brouillons": resultat["brouillons"]}


@application.post("/approbations")
def approuver(demande: DemandeApprobation) -> dict:
    """Le client envoie un identifiant, jamais un texte : le texte vient de l'etat."""
    etat = charger_etat()
    brouillon = etat["brouillons"].get(demande.brouillon_id)
    if brouillon is None:
        raise HTTPException(status_code=404, detail="brouillon inconnu")
    if brouillon["statut"] != "en_attente":
        raise HTTPException(status_code=409, detail="brouillon deja traite")
    brouillon["statut"] = "approuve" if demande.approuve else "refuse"
    if not demande.approuve:
        enregistrer_etat(etat)
        return {"brouillon_id": demande.brouillon_id, "statut": "refuse"}
    # Le validation_id nait ici, du geste d'une personne. L'agent ne peut pas l'inventer :
    # c'est ce qui rend l'ecriture impossible sans approbation.
    validation_id = f"VAL-{len(etat['validations']) + 1:03d}"
    etat["validations"][validation_id] = {"brouillon_id": demande.brouillon_id,
                                          "valideur": demande.valideur}
    enregistrer_etat(etat)
    return {"brouillon_id": demande.brouillon_id, "statut": "approuve",
            "validation_id": validation_id}
