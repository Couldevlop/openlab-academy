"""Compteurs de l'agent, exposes au format texte lu par les collecteurs."""
import threading
import time
from collections import defaultdict

_VERROU = threading.Lock()
_COMPTEURS: dict[tuple[str, tuple], int] = defaultdict(int)
_DUREES: dict[str, list[float]] = defaultdict(list)


def compter(nom: str, **etiquettes: str) -> None:
    """Incremente un compteur. N'etiquetez jamais par client ou par facture :
    une etiquette a forte cardinalite fait exploser le collecteur et y ecrit
    des donnees personnelles."""
    cle = (nom, tuple(sorted(etiquettes.items())))
    with _VERROU:
        _COMPTEURS[cle] += 1


def observer_duree(nom: str, secondes: float) -> None:
    with _VERROU:
        _DUREES[nom].append(secondes)
        if len(_DUREES[nom]) > 1000:        # fenetre glissante, memoire bornee
            del _DUREES[nom][:-1000]


class Chrono:
    """Mesure la duree d'un bloc : with Chrono("appel_modele"): ..."""

    def __init__(self, nom: str) -> None:
        self.nom = nom

    def __enter__(self) -> "Chrono":
        self.debut = time.perf_counter()
        return self

    def __exit__(self, *_exception) -> None:
        observer_duree(self.nom, time.perf_counter() - self.debut)


def _centile(valeurs: list[float], part: float) -> float:
    if not valeurs:
        return 0.0
    triees = sorted(valeurs)
    return triees[min(int(len(triees) * part), len(triees) - 1)]


def rendu() -> str:
    """Format texte : une ligne par serie, lisible par un humain comme par l'outil."""
    lignes: list[str] = []
    with _VERROU:
        for (nom, etiquettes), valeur in sorted(_COMPTEURS.items()):
            suffixe = ""
            if etiquettes:
                suffixe = "{" + ",".join(f'{c}="{v}"' for c, v in etiquettes) + "}"
            lignes.append(f"{nom}{suffixe} {valeur}")
        for nom, valeurs in sorted(_DUREES.items()):
            lignes.append(f"{nom}_p50_secondes {_centile(valeurs, 0.50):.3f}")
            lignes.append(f"{nom}_p95_secondes {_centile(valeurs, 0.95):.3f}")
    return "\n".join(lignes) + "\n"
