"""Journal structure : une ligne JSON par evenement, filtree a l'ecriture."""
import json
import sys
import time
import uuid
from typing import Any

INTERDITES = {"cle_api", "authorization", "note_libre", "notes", "texte_brouillon",
              "corps", "email", "telephone"}
TRONQUER_A = 200


def _assainir(valeur: Any) -> Any:
    if isinstance(valeur, dict):
        return {c: ("***" if c.lower() in INTERDITES else _assainir(v))
                for c, v in valeur.items()}
    if isinstance(valeur, list):
        return [_assainir(v) for v in valeur[:20]]
    if isinstance(valeur, str) and len(valeur) > TRONQUER_A:
        return valeur[:TRONQUER_A] + "...[tronque]"
    return valeur


def nouvelle_execution() -> str:
    """Un identifiant par execution : c'est lui qui relie toutes les lignes."""
    return f"exe-{uuid.uuid4().hex[:12]}"


def ecrire(execution_id: str, evenement: str, **champs: Any) -> None:
    ligne = {
        "horodatage": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "execution_id": execution_id,
        "evenement": evenement,
        **_assainir(champs),
    }
    # Sortie standard : l'orchestrateur se charge de la collecte et de la retention.
    print(json.dumps(ligne, ensure_ascii=False), file=sys.stdout, flush=True)
