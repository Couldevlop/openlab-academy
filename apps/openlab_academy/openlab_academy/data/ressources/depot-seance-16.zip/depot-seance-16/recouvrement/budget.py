"""Plafond de depense journalier : un interrupteur, pas un indicateur."""
import json
import pathlib
from datetime import date

CHEMIN = pathlib.Path("donnees/depense.json")


class BudgetDepasse(RuntimeError):
    """Refus explicite : le montant atteint figure dans le message."""


def _lire() -> dict:
    if not CHEMIN.exists():
        return {"jour": date.today().isoformat(), "fcfa": 0}
    donnees = json.loads(CHEMIN.read_text(encoding="utf-8"))
    if donnees.get("jour") != date.today().isoformat():
        return {"jour": date.today().isoformat(), "fcfa": 0}   # remise a zero du jour
    return donnees


def depense_du_jour() -> int:
    return _lire()["fcfa"]


def verifier_avant_execution(plafond_fcfa: int) -> None:
    """Appelee au debut de chaque execution, avant tout appel au modele."""
    actuelle = depense_du_jour()
    if actuelle >= plafond_fcfa:
        raise BudgetDepasse(
            f"plafond journalier atteint : {actuelle} F CFA sur {plafond_fcfa}. "
            "Relevez PLAFOND_FCFA en connaissance de cause ou attendez demain.")


def ajouter_depense(fcfa: int) -> int:
    """Appelee apres chaque appel au modele, avec le cout calcule sur les jetons."""
    donnees = _lire()
    donnees["fcfa"] += max(0, int(fcfa))
    CHEMIN.parent.mkdir(parents=True, exist_ok=True)
    CHEMIN.write_text(json.dumps(donnees), encoding="utf-8")
    return donnees["fcfa"]
