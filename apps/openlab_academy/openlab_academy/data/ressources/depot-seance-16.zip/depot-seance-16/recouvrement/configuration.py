"""Configuration lue a l'environnement, verifiee au demarrage, jamais journalisee."""
import os
from dataclasses import dataclass


class ConfigurationIncomplete(RuntimeError):
    """Levee au demarrage, pas a la premiere requete : c'est voulu."""


@dataclass(frozen=True)
class Configuration:
    cle_api: str
    modele: str
    base_url: str
    etat_chemin: str
    budget_fcfa: int
    journal_niveau: str

    def __repr__(self) -> str:          # protege contre un print() distrait
        return (f"Configuration(modele={self.modele!r}, base_url={self.base_url!r}, "
                f"cle_api='***')")


def _obligatoire(nom: str) -> str:
    valeur = os.environ.get(nom, "").strip()
    if not valeur:
        raise ConfigurationIncomplete(
            f"variable {nom} absente : renseignez-la dans le gestionnaire de secrets")
    return valeur


def charger_configuration() -> Configuration:
    return Configuration(
        cle_api=_obligatoire("CLE_MODELE"),
        modele=os.environ.get("MODELE", "gpt-4o-mini"),
        base_url=os.environ.get("BASE_URL", "https://api.openai.com/v1"),
        etat_chemin=os.environ.get("ETAT_CHEMIN", "donnees/etat.json"),
        budget_fcfa=int(os.environ.get("BUDGET_FCFA", "500")),
        journal_niveau=os.environ.get("JOURNAL_NIVEAU", "INFO"),
    )
